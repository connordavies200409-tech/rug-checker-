/*
 * Rug Checker core: fetches coin data and scores rug risk for Solana tokens.
 * No DOM code in here, so the same file runs in the page, the extension and Node tests.
 *
 * Data sources (all free, no API key):
 *   DexScreener  - price, liquidity, pools, coin feeds
 *   RugCheck     - token report: creator wallet, authorities, holders, LP, risks, creator history
 *   Solana RPC   - dev wallet age/activity, and a scan of the dev's transactions for coins they launched
 *   GoPlus       - scam flags on the dev wallet
 */
(function (root, factory) {
  const api = factory(root);
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.RugCore = api;
})(typeof window !== 'undefined' ? window : globalThis, function (root) {
  'use strict';

  const DEX = 'https://api.dexscreener.com';
  const RUG = 'https://api.rugcheck.xyz';
  const GOPLUS = 'https://api.gopluslabs.io';
  const FX = 'https://api.fxtwitter.com';   // free X/Twitter profile lookups (FxTwitter)
  const X_RESERVED = new Set(['home', 'search', 'explore', 'i', 'intent', 'share', 'hashtag', 'notifications', 'messages', 'settings', 'login', 'signup', 'tos', 'privacy', 'compose']);
  const DEFAULT_RPCS = ['https://solana-rpc.publicnode.com', 'https://api.mainnet-beta.solana.com'];
  const B58 = /^[1-9A-HJ-NP-Za-km-z]{32,44}$/;
  const LAMPORTS = 1e9;
  const SYSTEM_PROGRAM = '11111111111111111111111111111111';
  const TOKEN_PROGRAMS = ['TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA', 'TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb'];
  // What a pool pairs a meme coin against: wrapped SOL, USDC, USDT.
  const QUOTE_MINTS = new Set([
    'So11111111111111111111111111111111111111112',
    'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v',
    'Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB'
  ]);
  const AUTO_SCAN = 30;       // dev transactions scanned automatically
  const FUND_SCAN = 20;       // funder transactions scanned for launches and fan-out
  const BUNDLE_SLOTS = 2;     // launch window for the bundle check: creation slot + 2 (about a second)
  const BUNDLE_TXS = 20;      // most transactions read from that window
  const SCAN_WORKERS = 3;     // parallel getTransaction calls (public RPCs rate-limit hard)
  const SCAN_PAUSE_MS = 150;

  const FLAG_LABELS = {
    honeypot_related_address: 'linked to scam or honeypot tokens',
    fake_token: 'has made fake tokens',
    phishing_activities: 'phishing',
    stealing_attack: 'stealing attacks',
    blackmail_activities: 'blackmail',
    cybercrime: 'cybercrime',
    money_laundering: 'money laundering',
    financial_crime: 'financial crime',
    darkweb_transactions: 'darkweb transactions',
    sanctioned: 'sanctioned',
    mixer: 'uses a coin mixer',
    fake_kyc: 'fake KYC',
    malicious_mining_activities: 'malicious mining',
    blacklist_doubt: 'suspected malicious'
  };

  // ---------- small helpers ----------
  const isAddress = (s) => typeof s === 'string' && B58.test(s.trim());
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const num = (v) => (v === null || v === undefined || v === '' || !isFinite(Number(v)) ? null : Number(v));
  const liqOf = (p) => (p && p.liquidity && Number(p.liquidity.usd)) || 0;
  const keyOf = (k) => (typeof k === 'string' ? k : k && k.pubkey);
  const plural = (n, w) => n + ' ' + w + (n === 1 ? '' : 's');

  const MONTHS = { Jan: 0, Feb: 1, Mar: 2, Apr: 3, May: 4, Jun: 5, Jul: 6, Aug: 7, Sep: 8, Oct: 9, Nov: 10, Dec: 11 };
  function toMs(v) {
    if (v === null || v === undefined || v === '') return null;
    if (typeof v === 'number') return v < 1e12 ? v * 1000 : v;
    // X's own date format ("Wed Oct 10 20:19:24 +0000 2018"), which Safari can't parse by itself
    const m = /^\w{3} (\w{3}) (\d{1,2}) (\d{2}):(\d{2}):(\d{2}) ([+-])(\d{2})(\d{2}) (\d{4})$/.exec(String(v).trim());
    if (m && MONTHS[m[1]] !== undefined) {
      // groups: 1 month, 2 day, 3-5 h:m:s, 6 offset sign, 7-8 offset hh mm, 9 year
      const off = (m[6] === '-' ? -1 : 1) * (Number(m[7]) * 60 + Number(m[8])) * 60000;
      return Date.UTC(Number(m[9]), MONTHS[m[1]], Number(m[2]), Number(m[3]), Number(m[4]), Number(m[5])) - off;
    }
    const t = Date.parse(v);
    return isNaN(t) ? null : t;
  }
  function count(n) {
    n = num(n);
    if (n === null) return '–';
    if (n >= 1e6) return (n / 1e6).toFixed(n >= 1e7 ? 0 : 1) + 'M';
    if (n >= 1e4) return Math.round(n / 1e3) + 'k';
    if (n >= 1e3) return (n / 1e3).toFixed(1) + 'k';
    return String(n);
  }

  function usd(n) {
    n = num(n);
    if (n === null) return '–';
    const a = Math.abs(n);
    if (a >= 1e9) return '$' + (n / 1e9).toFixed(2) + 'B';
    if (a >= 1e6) return '$' + (n / 1e6).toFixed(2) + 'M';
    if (a >= 1e3) return '$' + (n / 1e3).toFixed(1) + 'k';
    if (a >= 1) return '$' + n.toFixed(a < 10 ? 2 : 0);
    if (a === 0) return '$0';
    return '$' + n.toPrecision(3);
  }
  function pct(n, d) {
    n = num(n);
    if (n === null) return '–';
    const p = Math.pow(10, d === undefined ? 1 : d);
    return Math.round(n * p) / p + '%';
  }
  const signedPct = (n) => (num(n) === null ? '–' : (n > 0 ? '+' : '') + pct(n, Math.abs(n) < 10 ? 1 : 0));
  function dur(ms) {
    const m = ms / 60000;
    if (m < 60) return Math.max(1, Math.round(m)) + ' min';
    const h = m / 60;
    if (h < 48) return Math.round(h) + ' h';
    const d = h / 24;
    if (d < 60) return Math.round(d) + ' days';
    const mo = d / 30.44;
    if (mo < 24) return Math.round(mo) + ' months';
    return (d / 365.25).toFixed(1) + ' years';
  }
  const ago = (ts, now) => dur(Math.max(0, (now || Date.now()) - ts)) + ' ago';
  const short = (a) => (a ? a.slice(0, 4) + '…' + a.slice(-4) : '');

  // RugCheck answers 4xx (other than 429) when it simply has no token at that address.
  const isNoReport = (e) => !!e && e.status >= 400 && e.status < 500 && e.status !== 429;

  function describeError(e) {
    if (!e) return 'unknown error';
    if (e.status === 429) return 'rate limited, try again in a minute';
    if (e.message === 'timed out') return 'timed out';
    if (e.status) return 'error ' + e.status;
    if (e.name === 'TypeError') return 'blocked or offline';
    return e.message || 'failed';
  }

  // ---------- DexScreener shapes ----------
  function coinFromPair(p, extra) {
    extra = extra || {};
    const c = {
      mint: extra.mint || (p && p.baseToken && p.baseToken.address) || null,
      name: null, symbol: null, icon: extra.icon || null,
      priceUsd: null, liquidity: null, mcap: null, fdv: null, volume24h: null,
      change1h: null, change24h: null, buys24h: null, sells24h: null,
      createdAt: null, dexId: null, url: null, pairAddress: null, socials: []
    };
    if (!p) return c;
    c.name = p.baseToken && p.baseToken.name || null;
    c.symbol = p.baseToken && p.baseToken.symbol || null;
    c.icon = extra.icon || (p.info && p.info.imageUrl) || null;
    c.priceUsd = num(p.priceUsd);
    c.liquidity = p.liquidity ? num(p.liquidity.usd) : null;
    c.mcap = num(p.marketCap);
    c.fdv = num(p.fdv);
    if (c.mcap === null) c.mcap = c.fdv;
    c.volume24h = p.volume ? num(p.volume.h24) : null;
    c.change1h = p.priceChange ? num(p.priceChange.h1) : null;
    c.change24h = p.priceChange ? num(p.priceChange.h24) : null;
    const t24 = p.txns && p.txns.h24;
    c.buys24h = t24 ? num(t24.buys) : null;
    c.sells24h = t24 ? num(t24.sells) : null;
    c.createdAt = num(p.pairCreatedAt);
    c.dexId = p.dexId || null;
    c.url = p.url || null;
    c.pairAddress = p.pairAddress || null;
    const info = p.info || {};
    (info.websites || []).forEach((w) => w && w.url && c.socials.push({ label: w.label || 'Website', url: w.url }));
    (info.socials || []).forEach((s) => {
      if (!s) return;
      const kind = s.type || s.platform || 'link';
      const url = s.url || (s.handle && /^https?:/.test(s.handle) ? s.handle : null);
      if (url) c.socials.push({ label: kind.charAt(0).toUpperCase() + kind.slice(1), url });
    });
    return c;
  }

  // base token address -> its most liquid Solana pair
  function bestPairs(pairs) {
    const map = new Map();
    (pairs || []).forEach((p) => {
      if (!p || p.chainId !== 'solana' || !p.baseToken || !p.baseToken.address) return;
      const k = p.baseToken.address;
      const cur = map.get(k);
      if (!cur || liqOf(p) > liqOf(cur)) map.set(k, p);
    });
    return map;
  }

  // ---------- X (Twitter) ----------
  // Works out what an X link points at: an account, a single tweet, or a Community.
  function parseX(raw) {
    if (!raw || typeof raw !== 'string') return null;
    let s = raw.trim();
    const bare = s.replace(/^@/, '');
    if (/^\w{1,15}$/.test(bare)) return X_RESERVED.has(bare.toLowerCase()) ? null : { kind: 'profile', handle: bare, url: 'https://x.com/' + bare };
    if (!/^https?:\/\//i.test(s)) s = 'https://' + s;
    let u;
    try { u = new URL(s); } catch (e) { return null; }
    if (!/(^|\.)(x|twitter)\.com$/i.test(u.hostname)) return null;
    const parts = u.pathname.split('/').filter(Boolean);
    if (!parts.length) return null;
    if (parts[0].toLowerCase() === 'i') {
      if (parts[1] === 'communities' && /^\d+$/.test(parts[2] || '')) return { kind: 'community', id: parts[2], url: 'https://x.com/i/communities/' + parts[2] };
      const si = parts.indexOf('status');
      if (si >= 0 && /^\d+$/.test(parts[si + 1] || '')) return { kind: 'tweet', id: parts[si + 1], handle: null, url: 'https://x.com/i/status/' + parts[si + 1] };
      return { kind: 'other', url: 'https://x.com' + u.pathname };
    }
    const handle = parts[0];
    if (!/^\w{1,15}$/.test(handle) || X_RESERVED.has(handle.toLowerCase())) return { kind: 'other', url: 'https://x.com' + u.pathname };
    if ((parts[1] === 'status' || parts[1] === 'statuses') && /^\d+$/.test(parts[2] || '')) {
      return { kind: 'tweet', id: parts[2], handle, url: 'https://x.com/' + handle + '/status/' + parts[2] };
    }
    return { kind: 'profile', handle, url: 'https://x.com/' + handle };
  }

  // Social links from a token's metadata JSON (pump.fun and most launchpads keep them there).
  function metaLinks(meta) {
    const out = { twitter: null, website: null, telegram: null };
    if (!meta || typeof meta !== 'object') return out;
    const put = (key, v) => {
      if (typeof v !== 'string' || !v.trim()) return;
      key = String(key || '').toLowerCase();
      if (!out.twitter && /^(twitter|x|twitter_?url)$/.test(key)) out.twitter = v.trim();
      else if (!out.website && /^(website|site|web)$/.test(key)) out.website = v.trim();
      else if (!out.telegram && /^(telegram|tg)$/.test(key)) out.telegram = v.trim();
    };
    [meta, meta.extensions, meta.links, meta.properties && meta.properties.links].forEach((o) => {
      if (o && typeof o === 'object' && !Array.isArray(o)) Object.keys(o).forEach((k) => put(k, o[k]));
    });
    [meta.socials, meta.links].forEach((arr) => {
      if (Array.isArray(arr)) arr.forEach((s) => s && put(s.type || s.platform || s.name, s.url || s.handle));
    });
    return out;
  }

  function normalizeXUser(u) {
    if (!u || !u.screen_name) return null;
    const ab = u.about_account || {};
    const rn = ab.username_changes || null;
    return {
      handle: u.screen_name,
      name: u.name || '',
      followers: num(u.followers),
      following: num(u.following),
      posts: num(u.statuses !== undefined ? u.statuses : u.tweets),
      joined: toMs(u.joined),
      description: u.description || (u.raw_description && u.raw_description.text) || '',
      verified: !!(u.verification && u.verification.verified),
      verifiedType: (u.verification && u.verification.type) || null,
      protected: !!u.protected,
      renames: rn ? num(rn.count) : null,
      lastRename: rn ? toMs(rn.last_changed_at) : null,
      basedIn: ab.based_in || null,
      website: (u.website && u.website.url) || null
    };
  }

  // ---------- RugCheck / on-chain shapes ----------
  function parseMintAccount(acc) {
    const v = acc && acc.value;
    if (!v) return { missing: true };
    const p = v.data && v.data.parsed;
    if (!p || p.type !== 'mint') return { notMint: true, owner: v.owner || null };
    const i = p.info || {};
    return {
      mintAuthority: i.mintAuthority || null,
      freezeAuthority: i.freezeAuthority || null,
      supply: num(i.supply),
      decimals: i.decimals,
      program: v.owner
    };
  }

  // undefined = unknown, null = revoked, string = still set
  function authorities(r) {
    const m = r.mintInfo && !r.mintInfo.notMint && !r.mintInfo.missing ? r.mintInfo : null;
    const rug = r.rug;
    const get = (k) => {
      if (m) return m[k] || null;
      if (rug) {
        const v = rug[k] !== undefined ? rug[k] : rug.token && rug.token[k];
        return v || null;
      }
      return undefined;
    };
    return { mint: get('mintAuthority'), freeze: get('freezeAuthority') };
  }

  // Pools, curves and lockers: accounts that hold supply but aren't people.
  function poolSet(rug) {
    const skip = new Set();
    if (!rug) return skip;
    Object.keys(rug.knownAccounts || {}).forEach((addr) => {
      const v = rug.knownAccounts[addr];
      if (v && v.type && v.type !== 'CREATOR') skip.add(addr);
    });
    (rug.markets || []).forEach((m) => {
      [m.pubkey, m.liquidityA, m.liquidityB,
        m.liquidityAAccount && m.liquidityAAccount.owner,
        m.liquidityBAccount && m.liquidityBAccount.owner].forEach((a) => a && skip.add(a));
    });
    return skip;
  }
  // Real holders (pools taken out), biggest first.
  function holderList(rug) {
    if (!rug || !Array.isArray(rug.topHolders)) return [];
    const skip = poolSet(rug);
    return rug.topHolders.filter((h) => h && h.owner && !skip.has(h.owner) && !skip.has(h.address))
      .map((h) => ({ owner: h.owner, pct: num(h.pct) || 0, insider: !!h.insider }));
  }

  // Every instruction in a parsed transaction, outer and inner.
  function allIxs(tx) {
    if (!tx || !tx.transaction || !tx.transaction.message) return [];
    const out = (tx.transaction.message.instructions || []).slice();
    ((tx.meta && tx.meta.innerInstructions) || []).forEach((inner) => out.push.apply(out, inner.instructions || []));
    return out;
  }
  // Plain SOL transfers in a transaction: [{ from, to, lamports }]
  function solTransfers(tx) {
    return allIxs(tx).filter((ix) => ix && ix.program === 'system' && ix.parsed && ix.parsed.type === 'transfer' && ix.parsed.info)
      .map((ix) => ({ from: ix.parsed.info.source, to: ix.parsed.info.destination, lamports: num(ix.parsed.info.lamports) || 0 }));
  }
  // Run fn over items with at most `n` running at once.
  async function mapLimit(items, n, fn) {
    const out = new Array(items.length);
    let i = 0;
    const worker = async () => {
      while (i < items.length) {
        const k = i++;
        try { out[k] = await fn(items[k], k); } catch (e) { out[k] = null; }
      }
    };
    const ws = [];
    for (let w = 0; w < Math.min(n, items.length); w++) ws.push(worker());
    await Promise.all(ws);
    return out;
  }

  // Exit check: what selling a position of `sizeSol` (valued at today's price) into the main pool
  // would cost in slippage and fees. Constant-product estimate; buying and instantly selling back
  // only loses fees in such a pool, so the useful number is the cost of getting out at your size.
  function exitCheck(pair, sizeSol) {
    if (!pair || !pair.liquidity) return null;
    const qs = String((pair.quoteToken && pair.quoteToken.symbol) || '').toUpperCase();
    if (qs !== 'SOL' && qs !== 'WSOL') return { unsupported: true, quote: qs || '?' };
    const quote = num(pair.liquidity.quote);
    const S = num(sizeSol) || 1;
    if (!quote || quote <= 0) return null;
    const dex = String(pair.dexId || '');
    const fee = dex === 'pumpfun' ? 0.01 : /pumpswap/.test(dex) ? 0.0025 : 0.003;
    // Selling tokens worth S SOL at spot returns quote*S/(quote+S), minus the fee.
    const sellSlipPct = (1 - (1 - fee) * quote / (quote + S)) * 100;
    // Buying with S SOL pays an average price S/quote above spot, plus the fee.
    const buySlipPct = (S / quote + fee) * 100;
    return {
      sizeSol: S,
      sellSlipPct,
      buySlipPct,
      maxSol5: quote * (0.05 - fee) / (1 - 0.05), // biggest position you could sell for about 5% total
      poolSol: quote,
      approx: dex === 'pumpfun' || /dlmm|clmm|whirlpool|orca|meteora/i.test(dex)
    };
  }

  // Top-holder stats with pools, curves and lockers taken out.
  function holderStats(rug) {
    if (!rug || !Array.isArray(rug.topHolders) || !rug.topHolders.length) return null;
    const skip = poolSet(rug);
    const list = rug.topHolders.filter((h) => h && !skip.has(h.owner) && !skip.has(h.address));
    const top = list.slice(0, 10);
    return {
      top10: top.reduce((s, h) => s + (num(h.pct) || 0), 0),
      maxSingle: top.reduce((mx, h) => Math.max(mx, num(h.pct) || 0), 0),
      insiders: list.filter((h) => h.insider).length,
      holders: num(rug.totalHolders),
      excluded: rug.topHolders.length - list.length
    };
  }

  const LOCKER_NAMES = { streamflow: 'Streamflow', jupiter_locker: 'Jupiter Lock', raydium_locker: 'Raydium lock', flux_locker: 'Flux lock', uncx: 'UNCX', guacamole: 'Guacamole' };
  const lockerName = (t) => LOCKER_NAMES[t] || String(t || 'locker').replace(/_/g, ' ');
  const POOL_NAMES = {
    pump_fun: 'pump.fun curve', pump_amm: 'PumpSwap', pumpswap: 'PumpSwap', pump_swap: 'PumpSwap',
    raydium: 'Raydium', raydium_cpmm: 'Raydium CPMM', raydium_clmm: 'Raydium CLMM', raydium_launchlab: 'Raydium LaunchLab',
    meteora: 'Meteora', meteoraDlmm: 'Meteora DLMM', meteora_dlmm: 'Meteora DLMM', meteoraDamm: 'Meteora DAMM', orca: 'Orca Whirlpool'
  };
  const poolName = (t) => POOL_NAMES[t] || String(t || 'unknown pool').replace(/_/g, ' ');

  // Is the liquidity locked? Looks at every pool, not just the biggest, plus any time-locks.
  //   state: curve | locked | partial | unlocked | unverifiable | unknown
  function liquidityLock(rug, now) {
    if (!rug || !Array.isArray(rug.markets) || !rug.markets.length) return null;
    now = now || Date.now();
    const pools = rug.markets.filter((m) => m && m.lp).map((m) => {
      const type = String(m.marketType || '');
      return {
        type,
        usd: (num(m.lp.baseUSD) || 0) + (num(m.lp.quoteUSD) || 0),
        lockedPct: num(m.lp.lpLockedPct),
        curve: /^pump_fun$|bonding|launchlab|moonshot/i.test(type),
        clmm: /dlmm|clmm|whirlpool|orca/i.test(type)
      };
    }).sort((a, b) => b.usd - a.usd);
    if (!pools.length) return null;
    const main = pools[0];
    const lockable = pools.filter((p) => !p.curve && !p.clmm && p.lockedPct !== null);
    const totalUSD = lockable.reduce((s, p) => s + p.usd, 0);
    const lockedUSD = lockable.reduce((s, p) => s + p.usd * Math.min(100, p.lockedPct) / 100, 0);
    // Time-locks still in force (an unlock date of 0 means no end date).
    const timeLocks = Object.keys(rug.lockers || {}).map((k) => rug.lockers[k]).filter((l) => l && num(l.usdcLocked) >= 1).map((l) => ({
      name: lockerName(l.type),
      usd: num(l.usdcLocked),
      unlockAt: num(l.unlockDate) ? num(l.unlockDate) * 1000 : null,
      url: typeof l.uri === 'string' ? l.uri : null
    })).filter((l) => !l.unlockAt || l.unlockAt > now).sort((a, b) => (a.unlockAt || Infinity) - (b.unlockAt || Infinity));
    const dated = timeLocks.filter((l) => l.unlockAt);
    let state;
    if (main.curve) state = 'curve';
    else if (main.clmm) state = 'unverifiable';
    else if (main.lockedPct === null) state = 'unknown';
    else if (main.lockedPct >= 95) state = 'locked';
    else if (main.lockedPct >= 50) state = 'partial';
    else state = 'unlocked';
    return {
      state, main, pools,
      lockedPct: main.lockedPct,
      lockedUSD: totalUSD ? lockedUSD : null,
      totalUSD: totalUSD || null,
      timeLocks,
      nextUnlock: dated.length ? dated[0].unlockAt : null
    };
  }
  // Kept for older callers: the biggest pool only.
  function mainLp(rug) {
    const l = liquidityLock(rug);
    return l ? { type: l.main.type, curve: l.main.curve, clmm: l.main.clmm, lockedPct: l.main.lockedPct } : null;
  }

  function normalizeCreatorTokens(list) {
    if (!Array.isArray(list)) return [];
    return list.map((t) => ({
      mint: t && (t.mint || t.address || t.tokenAddress),
      createdAt: t && toMs(t.createdAt || t.created_at || t.createAt),
      mcapHint: t ? num(t.marketCap !== undefined ? t.marketCap : t.market_cap) : null
    })).filter((t) => isAddress(t.mint || ''));
  }

  // Mints this transaction created, if the dev paid for it. A fresh coin's mint
  // keypair signs its own creation, which rules out pool LP mints (those are PDAs).
  function launchedMints(tx, creator) {
    if (!tx || !tx.transaction || !tx.transaction.message) return [];
    if (tx.meta && tx.meta.err) return [];
    const keys = tx.transaction.message.accountKeys || [];
    if (!keys.length || keyOf(keys[0]) !== creator) return [];
    const signers = new Set(keys.filter((k) => typeof k === 'object' && k.signer).map(keyOf));
    const ixs = (tx.transaction.message.instructions || []).slice();
    ((tx.meta && tx.meta.innerInstructions) || []).forEach((inner) => ixs.push.apply(ixs, inner.instructions || []));
    const out = [];
    ixs.forEach((ix) => {
      const p = ix && ix.parsed;
      if (!p || typeof p !== 'object' || !/^initializeMint/.test(p.type || '')) return;
      const m = p.info && p.info.mint;
      if (m && m !== creator && signers.has(m) && out.indexOf(m) < 0) out.push(m);
    });
    return out;
  }

  function classify(it, now) {
    const c = it.coin || {};
    const born = it.createdAt || c.createdAt;
    const age = born ? now - born : null;
    const mc = c.mcap;
    const lq = c.liquidity;
    if ((mc !== null && mc >= 100000) || (lq !== null && lq >= 25000)) return 'alive';
    if (age !== null && age < 6 * 3600e3) return 'new';
    if ((mc === null || mc < 10000) && (lq === null || lq < 2000)) return 'dead';
    return 'small';
  }

  // ---------- scoring ----------
  function assess(r, now) {
    now = now || Date.now();
    const found = [];
    let pts = 0;
    let rugged = false;
    const add = (tone, text, p, group) => { found.push({ tone, text, pts: p || 0, group }); pts += p || 0; };
    const rug = r.rug;
    const c = r.coin || {};
    const st = r.status || {};

    if (rug && rug.rugged) { rugged = true; add('bad', 'RugCheck has marked this coin as rugged.', 100, 'token'); }

    // Token switches
    const auth = authorities(r);
    if (auth.mint) add('bad', 'The dev can still mint new tokens and dilute everyone.', 25, 'token');
    else if (auth.mint === null) add('good', 'Mint authority is revoked: no new tokens can be made.', 0, 'token');
    if (auth.freeze) add('bad', 'The dev can freeze wallets, which would stop you selling.', 25, 'token');
    else if (auth.freeze === null) add('good', 'Freeze authority is revoked.', 0, 'token');
    if (rug && rug.tokenMeta && rug.tokenMeta.mutable) add('warn', 'The dev can still change the name, image and links.', 5, 'token');
    const fee = rug && rug.transferFee ? num(rug.transferFee.pct) : null;
    if (fee > 0) add(fee >= 10 ? 'bad' : 'warn', 'Every transfer pays a ' + pct(fee) + ' fee.', fee >= 10 ? 25 : 10, 'token');

    // Holders
    const h = holderStats(rug);
    if (h) {
      if (h.top10 > 50) add('bad', 'The top 10 wallets hold ' + pct(h.top10, 0) + ' of the supply.', 15, 'holders');
      else if (h.top10 > 30) add('warn', 'The top 10 wallets hold ' + pct(h.top10, 0) + ' of the supply.', 8, 'holders');
      else if (h.holders !== null && h.holders >= 50) add('good', 'Supply is spread out: the top 10 wallets hold ' + pct(h.top10, 0) + '.', 0, 'holders');
      if (h.maxSingle > 15) add('warn', 'One wallet holds ' + pct(h.maxSingle, 0) + ' of the supply.', 8, 'holders');
    }
    const ins = rug ? num(rug.graphInsidersDetected) : null;
    if (ins > 0) add('bad', 'RugCheck found ' + plural(ins, 'insider wallet') + ' linked to each other (bundled or sniped supply).', ins >= 5 ? 15 : 10, 'holders');

    // Market
    if (st.dex && st.dex.state === 'ok' && !r.pairs.length) add('warn', 'No trading pool on DexScreener yet.', 10, 'market');
    else if (c.liquidity !== null && c.liquidity !== undefined) {
      if (c.liquidity < 1000) add('bad', 'Only ' + usd(c.liquidity) + ' of liquidity. Selling even a small bag will crash the price.', 20, 'market');
      else if (c.liquidity < 10000) add('warn', 'Thin liquidity: ' + usd(c.liquidity) + '.', 8, 'market');
    }
    // Liquidity lock
    const lock = liquidityLock(rug, now);
    if (lock) {
      const lp = lock.main;
      if (lock.state === 'curve') add('info', "Still on the launchpad's bonding curve, so the liquidity can't be pulled. The dev can still dump their tokens.", 0, 'lock');
      else if (lock.state === 'unlocked') add('bad', 'Liquidity is NOT locked: only ' + pct(lp.lockedPct, 0) + ' of the main pool is locked or burned. The dev can pull the rest.', 20, 'lock');
      else if (lock.state === 'partial') add('warn', 'Liquidity is only partly locked: ' + pct(lp.lockedPct, 0) + ' of the main pool. The rest can be pulled.', 8, 'lock');
      else if (lock.state === 'locked') add('good', 'Liquidity is locked or burned (' + pct(lp.lockedPct, 0) + ' of the main pool).', 0, 'lock');
      else if (lock.state === 'unverifiable') add('warn', 'The main pool is a concentrated-liquidity pool (' + poolName(lp.type) + "), where a lock can't be verified. Liquidity there can usually be withdrawn.", 5, 'lock');
      if (lock.nextUnlock) {
        const left = lock.nextUnlock - now;
        if (left < 7 * 24 * 3600e3) add('bad', 'A liquidity lock expires in ' + dur(left) + '. After that it can be pulled.', 15, 'lock');
        else if (left < 30 * 24 * 3600e3) add('warn', 'A liquidity lock expires in ' + dur(left) + '.', 5, 'lock');
      }
    }
    if (c.createdAt && now - c.createdAt < 3600e3) add('info', 'Under an hour old. Most rugs happen in the first few hours.', 5, 'market');

    // The dev
    if (r.creatorPct !== null && r.creatorPct !== undefined) {
      if (r.creatorPct > 10) add('bad', 'The dev still holds ' + pct(r.creatorPct, 0) + ' of the supply.', 12, 'dev');
      else if (r.creatorPct > 3) add('warn', 'The dev holds ' + pct(r.creatorPct) + ' of the supply.', 5, 'dev');
    }
    const w = r.wallet;
    if (w && w.firstSeen && !w.capped) {
      const age = now - w.firstSeen;
      if (age < 24 * 3600e3) add('bad', 'The dev wallet is brand new: first used ' + ago(w.firstSeen, now) + '.', 15, 'dev');
      else if (age < 7 * 24 * 3600e3) add('warn', 'The dev wallet is only ' + dur(age) + ' old.', 8, 'dev');
      else if (age > 90 * 24 * 3600e3) add('good', 'The dev wallet has been in use for ' + dur(age) + '.', 0, 'dev');
    }
    if (r.devFlags) {
      const f = r.devFlags;
      if (f.labels.length || f.malicious > 0) {
        const bits = f.labels.slice();
        if (f.malicious > 0) bits.push(plural(f.malicious, 'malicious contract') + ' created');
        add('bad', 'GoPlus flags the dev wallet: ' + bits.join(', ') + '.', 30, 'dev');
      } else add('good', 'GoPlus has no scam flags on the dev wallet.', 0, 'dev');
    }

    // The dev's other coins
    const L = r.launches;
    if (L && !L.progress && (L.scanned > 0 || L.fromRugcheck > 0)) {
      const prev = L.items;
      const judged = prev.filter((x) => x.status && x.status !== 'new' && x.status !== 'unknown');
      const dead = judged.filter((x) => x.status === 'dead').length;
      const alive = prev.filter((x) => x.status === 'alive');
      if (judged.length >= 3 && dead / judged.length >= 0.8) add('bad', 'The dev has launched ' + plural(judged.length, 'other coin') + ' and ' + dead + ' of them are dead.', 30, 'history');
      else if (dead >= 1) add('warn', dead + ' of the dev\'s ' + plural(judged.length, 'other coin') + (dead === 1 ? ' is' : ' are') + ' dead.', Math.min(20, 6 * dead), 'history');
      if (prev.length >= 10) add('warn', 'Serial launcher: ' + plural(prev.length, 'other coin') + ' from this wallet.', 10, 'history');
      if (alive.length) {
        const best = alive.slice().sort((a, b) => (b.coin.mcap || 0) - (a.coin.mcap || 0))[0];
        const nm = best.coin.symbol ? '$' + best.coin.symbol : short(best.mint);
        add('good', alive.length + ' of the dev\'s earlier coins ' + (alive.length === 1 ? 'is' : 'are') + ' still alive (biggest: ' + nm + ' at ' + usd(best.coin.mcap) + ').', -10, 'history');
      }
      if (!prev.length) add('info', L.scanned ? 'No other launches found in the dev\'s last ' + plural(L.scanned, 'transaction') + '.' : 'No other launches on record for this wallet.', 0, 'history');
    }

    // The coin's X account
    const x = r.x;
    if (x && x.kind) {
      const launchTimes = [c.createdAt, rug && toMs(rug.detectedAt)].filter((t) => t);
      const launchAt = launchTimes.length ? Math.min.apply(null, launchTimes) : null;
      if (x.kind === 'none') add('info', 'No X account is linked to this coin.', 0, 'x');
      else if (x.kind === 'community') add('info', 'Its X link is a Community, which anyone can set up in seconds.', 0, 'x');
      else if (x.kind === 'tweet') {
        if (x.state === 'notfound') add('warn', 'Its X link points to a tweet that no longer exists.', 8, 'x');
        else if (x.tweet && x.tweet.author) {
          const f = x.user && x.user.followers;
          add('warn', 'Its X link is a tweet by @' + x.tweet.author + (f >= 10000 ? ' (' + count(f) + ' followers)' : '') + ', not an account run by the team. Nobody behind this coin is on record.', 5, 'x');
        }
      } else if (x.kind === 'profile') {
        if (x.state === 'suspended') add('bad', 'The linked X account @' + x.handle + ' is suspended.', 20, 'x');
        else if (x.state === 'notfound') add('bad', 'The linked X account @' + x.handle + " doesn't exist.", 15, 'x');
        else if (x.user) {
          const u = x.user;
          if (u.joined && launchAt && u.joined > launchAt - 2 * 24 * 3600e3) {
            add('warn', 'The X account was created ' + (u.joined <= launchAt ? dur(launchAt - u.joined) + ' before' : dur(u.joined - launchAt) + ' after') + ' the coin launched.', 8, 'x');
          } else if (u.joined && now - u.joined > 180 * 24 * 3600e3 && u.renames === 0) {
            add('good', 'The X account is ' + dur(now - u.joined) + ' old and has never changed its @.', 0, 'x');
          }
          if (u.renames >= 1) {
            const recent = u.lastRename && now - u.lastRename < 30 * 24 * 3600e3;
            add(recent || u.renames >= 3 ? 'bad' : 'warn', 'The X account has changed its @ ' + plural(u.renames, 'time') + (u.lastRename ? ', most recently ' + ago(u.lastRename, now) : '') + '. Bought and recycled accounts are common in rugs.', recent || u.renames >= 3 ? 15 : 8, 'x');
          }
          if (u.followers !== null && u.followers < 100) add('warn', 'The X account has only ' + plural(u.followers, 'follower') + '.', 5, 'x');
          const cas = (u.description.match(/[1-9A-HJ-NP-Za-km-z]{32,44}/g) || []);
          if (cas.indexOf(r.mint) >= 0) add('good', 'The X bio lists this exact contract address.', 0, 'x');
          else if (cas.length) add('warn', 'The X bio lists a different address (' + short(cas[0]) + '), which may belong to another coin.', 10, 'x');
          if (u.verified && u.verifiedType === 'organization') add('good', 'The X account has a gold organization check.', 0, 'x');
        }
        // The same account reused across the dev's coins
        if (x.handle && r.launches && r.launches.items.length) {
          const hh = x.handle.toLowerCase();
          const reused = r.launches.items.filter((it) => it.coin && (it.coin.socials || []).some((s) => {
            const p = parseX(s.url);
            return p && p.handle && p.handle.toLowerCase() === hh;
          }));
          if (reused.length) add('bad', 'The same X account (@' + x.handle + ') was used for ' + plural(reused.length, 'other coin') + ' by this dev.', 20, 'x');
        }
      }
    }

    // Who funded the dev
    const fd = r.funding;
    if (fd && fd.state === 'ok' && fd.funder) {
      if (fd.highVolume) add('info', 'The dev was funded by a high-volume wallet (likely an exchange or service).', 0, 'funding');
      else {
        const fl = fd.launches || [];
        const fj = fl.filter((x) => x.status && x.status !== 'new' && x.status !== 'unknown');
        const fdead = fj.filter((x) => x.status === 'dead').length;
        if (fdead >= 2 || (fdead >= 1 && fdead / fj.length >= 0.5)) add('bad', 'The wallet that funded the dev has launched ' + plural(fl.length, 'coin') + ' itself, and ' + fdead + ' ' + (fdead === 1 ? 'is' : 'are') + ' dead. Same operator, fresh wallet.', 25, 'funding');
        else if (fl.length) add('warn', 'The wallet that funded the dev has launched ' + plural(fl.length, 'coin') + ' itself.', 8, 'funding');
        if (fd.recipients >= 10) add('warn', 'The funding wallet sent SOL to ' + fd.recipients + ' different wallets recently, a wallet-farm pattern.', 10, 'funding');
        if (fd.funderFirstSeen && now - fd.funderFirstSeen < 3 * 24 * 3600e3) add('warn', 'The funding wallet itself is only ' + dur(now - fd.funderFirstSeen) + ' old.', 5, 'funding');
      }
    }

    // Snipers and bundles at launch
    const bd = r.bundle;
    if (bd && bd.state === 'ok') {
      if (bd.wallets > 0 && bd.totalPct >= 25) add('bad', plural(bd.wallets, 'wallet') + ' bought ' + pct(bd.totalPct, 0) + ' of the supply in the first second (bundled or sniped).', 20, 'bundle');
      else if (bd.wallets > 0 && bd.totalPct >= 10) add('warn', plural(bd.wallets, 'wallet') + ' bought ' + pct(bd.totalPct, 0) + ' of the supply in the first second.', 10, 'bundle');
      else if (!bd.wallets || bd.totalPct < 3) add('good', 'No real sniping or bundling in the first second of trading.', 0, 'bundle');
      if (bd.stillHeldPct >= 10) add('bad', 'Those launch buyers still hold ' + pct(bd.stillHeldPct, 0) + ' between them, ready to dump.', 10, 'bundle');
      if (bd.devBuyPct >= 10) add('info', 'The dev bought ' + pct(bd.devBuyPct, 0) + ' of the supply at launch.', 0, 'bundle');
    }

    // Fresh wallets among the top holders
    const fh = r.holders;
    if (fh && fh.state === 'ok') {
      if (fh.fresh >= 5) add('bad', fh.fresh + ' of the top ' + fh.checked + ' holders are wallets made in the last day (' + pct(fh.freshPct, 0) + ' of supply). Likely fake holders.', 15, 'holders');
      else if (fh.fresh >= 3) add('warn', fh.fresh + ' of the top ' + fh.checked + ' holders are wallets made in the last day.', 8, 'holders');
    }

    // Copycats
    const cc = r.copycats;
    if (cc && cc.state === 'ok') {
      if (cc.original) add('warn', 'Possible copycat: an older ' + (cc.original.symbol ? '$' + cc.original.symbol : 'coin with this name') + ' already exists (' + usd(cc.original.mcap) + (cc.original.createdAt ? ', ' + dur(now - cc.original.createdAt) + ' old' : '') + ').', 10, 'copycat');
      else if (cc.isOriginal) add('good', 'This is the oldest coin with this ticker (' + cc.count + (cc.count === 1 ? ' copy' : ' copies') + ' found).', 0, 'copycat');
    }

    // Exit check
    const ex = exitCheck(r.pairs && r.pairs[0], r.exitSize || 1);
    if (ex && !ex.unsupported && ex.sellSlipPct >= 10) add('warn', 'Thin pool: selling a ' + ex.sizeSol + ' SOL position would cost about ' + pct(ex.sellSlipPct, 0) + ' in slippage (the pool holds ' + (Math.round(ex.poolSol * 10) / 10) + ' SOL).', 8, 'exit');

    // Your blacklist
    (r.blacklistHits || []).forEach((hit) => {
      const who = { coin: 'this coin', dev: 'the dev', funder: 'the wallet that funded the dev', sniper: 'a launch sniper', holder: 'a top holder' }[hit.role] || hit.role;
      add('bad', 'On your blacklist: ' + who + (hit.note ? ' (' + hit.note + ')' : '') + '.', hit.role === 'holder' || hit.role === 'sniper' ? 15 : 50, 'blacklist');
    });

    // RugCheck risks not already covered above
    let extra = 0;
    const covered = /mint|freeze|holder|liquidity|\blp\b|unlocked|mutable|insider|transfer fee|ownership|supply/i;
    ((rug && rug.risks) || []).forEach((k) => {
      if (!k || !k.name || covered.test(k.name) || extra >= 30) return;
      if (/rug|creator|history|copycat|duplicate/i.test(k.name)) { add('bad', 'RugCheck: ' + k.name + '.', 20, 'history'); extra += 20; }
      else if (k.level === 'danger') { add('bad', 'RugCheck: ' + k.name + '.', 10, 'token'); extra += 10; }
      else if (k.level === 'warn') { add('warn', 'RugCheck: ' + k.name + '.', 3, 'token'); extra += 3; }
    });

    const score = rugged ? 100 : Math.max(0, Math.min(100, Math.round(pts)));
    const tokenKnown = !!rug || !!(r.mintInfo && !r.mintInfo.notMint && !r.mintInfo.missing);
    const devKnown = !!r.creator && (!!r.wallet || !!r.devFlags);
    const complete = tokenKnown && devKnown;
    let verdict;
    if (rugged) verdict = { key: 'rugged', label: 'Rugged', tone: 'bad' };
    else if (score >= 55) verdict = { key: 'high', label: 'High rug risk', tone: 'bad' };
    else if (score >= 25) verdict = { key: 'caution', label: 'Be careful', tone: 'warn' };
    else if (!complete) verdict = { key: 'unknown', label: 'Check incomplete', tone: 'muted' };
    else verdict = { key: 'low', label: 'No red flags', tone: 'ok' };

    const order = { bad: 0, warn: 1, info: 2, good: 3 };
    found.sort((a, b) => order[a.tone] - order[b.tone] || b.pts - a.pts);
    return { score, verdict, findings: found, complete, tokenKnown, devKnown, holders: h, lp: lock ? lock.main : null, lock, auth, exit: ex };
  }

  // ---------- instant read: the six things a trader checks first ----------
  function quickFacts(r, a, now) {
    now = now || Date.now();
    a = a || assess(r, now);
    const st = r.status || {};
    const busy = (k) => !st[k] || st[k].state === 'loading';
    const F = [];
    const fact = (key, label, value, tone, note, extra) => F.push(Object.assign({ key, label, value, tone, note: note || '' }, extra || {}));
    const wait = (key, label, note) => fact(key, label, '…', 'muted', note || '', { busy: true });

    // Liquidity lock
    const L = a.lock;
    const LOCK = { locked: ['ok', 'Locked'], partial: ['warn', 'Partly locked'], unlocked: ['bad', 'NOT locked'], curve: ['muted', 'Bonding curve'], unverifiable: ['warn', "Can't verify"], unknown: ['muted', 'Unknown'] };
    if (busy('rugcheck')) wait('lock', 'Liquidity');
    else if (!L) fact('lock', 'Liquidity', r.rug ? 'No pool' : 'Unknown', 'muted', r.rug ? '' : r.rugMissing ? 'no RugCheck report yet' : 'RugCheck down');
    else {
      const m = LOCK[L.state] || LOCK.unknown;
      let note = '';
      if (L.state === 'curve') note = "can't be pulled yet";
      else if (L.lockedPct !== null && !L.main.clmm) note = pct(L.lockedPct, 0) + ' of main pool';
      if (L.nextUnlock && L.nextUnlock - now < 30 * 24 * 3600e3) note = 'unlocks in ' + dur(L.nextUnlock - now);
      fact('lock', 'Liquidity', m[1], L.nextUnlock && L.nextUnlock - now < 7 * 24 * 3600e3 ? 'bad' : m[0], note, { open: L.state === 'unlocked' || L.state === 'partial' });
    }

    // Mint / freeze authority
    const au = a.auth;
    if (au.mint === undefined && au.freeze === undefined) {
      if (busy('rugcheck')) wait('auth', 'Mint / freeze'); else fact('auth', 'Mint / freeze', 'Unknown', 'muted');
    } else if (au.mint && au.freeze) fact('auth', 'Mint / freeze', 'Both ON', 'bad', 'dev can mint and freeze');
    else if (au.mint) fact('auth', 'Mint / freeze', 'Can mint', 'bad', 'dev can print tokens');
    else if (au.freeze) fact('auth', 'Mint / freeze', 'Can freeze', 'bad', 'you may not be able to sell');
    else fact('auth', 'Mint / freeze', 'Revoked', 'ok', 'both switched off');

    // Dev wallet age
    const w = r.wallet;
    if (w && w.firstSeen) {
      const age = now - w.firstSeen;
      const tone = w.capped ? 'muted' : age < 24 * 3600e3 ? 'bad' : age < 7 * 24 * 3600e3 ? 'warn' : age > 90 * 24 * 3600e3 ? 'ok' : 'muted';
      fact('dev', 'Dev wallet', (w.capped ? '>' : '') + dur(age), tone, w.capped ? '1,000+ txs' : 'old, ' + plural(w.txCount, 'tx'));
    } else if (busy('rugcheck') || busy('rpc')) wait('dev', 'Dev wallet');
    else fact('dev', 'Dev wallet', 'Unknown', 'muted', r.creator ? 'history unavailable' : 'dev not found');

    // The dev's past coins
    const Ln = r.launches;
    if (Ln && Ln.progress) wait('history', 'Past coins', 'scanning ' + Ln.progress.done + '/' + Ln.progress.total);
    else if (!Ln) {
      if (!r.creator && !busy('rugcheck') && !busy('rpc')) fact('history', 'Past coins', 'Unknown', 'muted', 'dev not found');
      else wait('history', 'Past coins');
    } else {
      const prev = Ln.items;
      const judged = prev.filter((x) => x.status && x.status !== 'new' && x.status !== 'unknown');
      const dead = judged.filter((x) => x.status === 'dead').length;
      const alive = prev.filter((x) => x.status === 'alive').length;
      if (!prev.length) fact('history', 'Past coins', 'None found', 'muted', Ln.scanned ? 'last ' + Ln.scanned + ' txs' : '');
      else if (dead) fact('history', 'Past coins', dead + '/' + judged.length + ' dead', judged.length >= 3 && dead / judged.length >= 0.8 ? 'bad' : 'warn', alive ? alive + ' still alive' : 'launched by this dev');
      else if (alive) fact('history', 'Past coins', alive + ' alive', 'ok', 'of ' + prev.length + ' launched');
      else fact('history', 'Past coins', plural(prev.length, 'coin'), 'muted', 'none dead yet');
    }

    // Who funded the dev
    const fd = r.funding;
    const fundHit = (r.blacklistHits || []).some((h) => h.role === 'funder');
    if (!fd) {
      if (r.wallet || busy('rpc') || busy('rugcheck') || (r.creator && !st.rpc)) wait('funding', 'Funded by');
      else fact('funding', 'Funded by', 'Unknown', 'muted', r.creator ? 'wallet history unavailable' : 'dev not found');
    } else if (fd.state === 'loading') wait('funding', 'Funded by');
    else if (fd.state === 'skipped') fact('funding', 'Funded by', 'Not traced', 'muted', fd.note);
    else if (fd.state === 'error' || !fd.funder) fact('funding', 'Funded by', 'Unknown', 'muted', fd.note || 'trace failed');
    else if (fundHit) fact('funding', 'Funded by', 'Blacklisted', 'bad', 'a wallet on your list');
    else if (fd.highVolume) fact('funding', 'Funded by', 'Exchange?', 'muted', 'high-volume wallet');
    else {
      const fl = fd.launches || [];
      const fdead = fl.filter((x) => x.status === 'dead').length;
      if (fdead >= 1) fact('funding', 'Funded by', 'A rugger', fdead >= 2 ? 'bad' : 'warn', 'funder has ' + fdead + ' dead coin' + (fdead === 1 ? '' : 's'));
      else if (fd.recipients >= 10) fact('funding', 'Funded by', 'Wallet farm', 'warn', 'funder paid ' + fd.recipients + ' wallets');
      else fact('funding', 'Funded by', 'Clean', 'ok', short(fd.funder) + ' · ' + (Math.round(fd.sol * 100) / 100) + ' SOL');
    }

    // Snipers and bundles
    const bd = r.bundle;
    if (!bd || busy('bundle')) { if (busy('bundle') || !st.bundle) wait('bundle', 'Bundled'); else fact('bundle', 'Bundled', 'Unknown', 'muted'); }
    else if (bd.state === 'skipped') fact('bundle', 'Bundled', 'n/a', 'muted', bd.note);
    else if (bd.state !== 'ok') fact('bundle', 'Bundled', 'Unavailable', 'muted', bd.note);
    else if (!bd.wallets || bd.totalPct < 3) fact('bundle', 'Bundled', 'Clean', 'ok', 'no first-second buyers');
    else fact('bundle', 'Bundled', pct(bd.totalPct, 0), bd.totalPct >= 25 ? 'bad' : bd.totalPct >= 10 ? 'warn' : 'muted', plural(bd.wallets, 'wallet') + (bd.stillHeldPct >= 1 ? ' · hold ' + pct(bd.stillHeldPct, 0) : ''));

    // Top 10 holders (and how many are brand-new wallets)
    const hs = a.holders;
    const fh = r.holders && r.holders.state === 'ok' ? r.holders : null;
    if (hs) {
      let tone = hs.top10 > 50 ? 'bad' : hs.top10 > 30 ? 'warn' : 'ok';
      if (fh && fh.fresh >= 5) tone = 'bad'; else if (fh && fh.fresh >= 3 && tone === 'ok') tone = 'warn';
      fact('holders', 'Top 10', pct(hs.top10, 0), tone, fh ? fh.fresh + ' of ' + fh.checked + ' are fresh wallets' : busy('holders') ? 'checking wallet ages…' : 'of supply, pools excluded');
    } else if (busy('rugcheck')) wait('holders', 'Top 10');
    else fact('holders', 'Top 10', 'Unknown', 'muted');

    // X account
    const x = r.x;
    if (busy('x')) wait('x', 'X account');
    else if (!x) fact('x', 'X account', 'Unknown', 'muted', 'lookup failed');
    else if (x.kind === 'none') fact('x', 'X account', 'None', 'muted', 'no X linked');
    else if (x.kind === 'community') fact('x', 'X account', 'Community', 'muted', 'not a real account');
    else if (x.kind === 'tweet') fact('x', 'X account', x.state === 'notfound' ? 'Deleted post' : 'Just a post', x.state === 'notfound' ? 'bad' : 'warn', x.tweet && x.tweet.author ? 'by @' + x.tweet.author : '');
    else if (x.kind !== 'profile') fact('x', 'X account', 'Odd link', 'warn');
    else if (x.state === 'suspended') fact('x', 'X account', 'Suspended', 'bad', '@' + x.handle);
    else if (x.state === 'notfound') fact('x', 'X account', 'Deleted', 'bad', '@' + x.handle);
    else if (x.state === 'private') fact('x', 'X account', 'Protected', 'muted', '@' + x.handle);
    else if (x.state === 'error' || !x.user) fact('x', 'X account', 'Unavailable', 'muted', '@' + x.handle);
    else {
      const u = x.user;
      const launchTimes = [r.coin && r.coin.createdAt, r.rug && toMs(r.rug.detectedAt)].filter((t) => t);
      const launchAt = launchTimes.length ? Math.min.apply(null, launchTimes) : null;
      if (u.renames >= 1) {
        const recent = u.lastRename && now - u.lastRename < 30 * 24 * 3600e3;
        fact('x', 'X account', 'Renamed ' + u.renames + '×', recent || u.renames >= 3 ? 'bad' : 'warn', u.lastRename ? 'last ' + ago(u.lastRename, now) : '@' + u.handle);
      } else if (u.joined && launchAt && u.joined > launchAt - 2 * 24 * 3600e3) fact('x', 'X account', 'Brand new', 'warn', 'made ' + (u.joined <= launchAt ? dur(launchAt - u.joined) + ' before launch' : 'after launch'));
      else if (u.followers !== null && u.followers < 100) fact('x', 'X account', count(u.followers) + ' followers', 'warn', '@' + u.handle);
      else fact('x', 'X account', u.joined ? dur(now - u.joined) + ' old' : '@' + u.handle, 'ok', count(u.followers) + ' followers');
    }

    // Copycats
    const cc = r.copycats;
    if (!cc || busy('copycat')) { if (busy('copycat') || !st.copycat) wait('copycat', 'Copycats'); else fact('copycat', 'Copycats', 'Unknown', 'muted'); }
    else if (cc.state === 'skipped') fact('copycat', 'Copycats', 'n/a', 'muted', cc.note);
    else if (cc.state !== 'ok') fact('copycat', 'Copycats', 'Unavailable', 'muted');
    else if (cc.original) fact('copycat', 'Copycats', 'Is a copy', 'warn', 'older ' + (cc.original.symbol ? '$' + cc.original.symbol : 'twin') + ' at ' + usd(cc.original.mcap));
    else if (cc.isOriginal) fact('copycat', 'Copycats', 'Original', 'ok', cc.count + (cc.count === 1 ? ' copy' : ' copies') + ' after it');
    else if (!cc.count) fact('copycat', 'Copycats', 'Unique', 'ok', 'no same-ticker coins');
    else fact('copycat', 'Copycats', cc.count + ' twins', 'muted', 'same ticker, none bigger & older');
    return F;
  }

  // ---------- filtered launch feed ----------
  // Your rules for which new coins are worth a look. Quick rules use the token and market only;
  // dev rules need the full check (dev wallet, funder, launch snipers, holders).
  const DEFAULT_RULES = {
    maxScore: 40, lock: 'safe', authRevoked: true, top10Max: 30, minLiq: 0, maxAgeH: 24,
    deep: true, maxDeadCoins: 1, maxBundlePct: 20, maxFresh: 4
  };
  function filterCheck(r, rules, now) {
    rules = Object.assign({}, DEFAULT_RULES, rules || {});
    now = now || Date.now();
    const a = assess(r, now);
    const c = r.coin || {};
    const fails = [];
    const n2 = (v) => (v === '' || v === null || v === undefined || !isFinite(Number(v)) ? null : Number(v));
    if (r.blacklistHits && r.blacklistHits.length) fails.push('on your blacklist');
    if (a.verdict.key === 'rugged') fails.push('rugged');
    else if (n2(rules.maxScore) !== null && a.score > n2(rules.maxScore)) fails.push('risk ' + a.score + ' (max ' + n2(rules.maxScore) + ')');
    if (rules.lock === 'safe') {
      const st = a.lock ? a.lock.state : null;
      if (st !== 'locked' && st !== 'curve') fails.push({ unlocked: 'LP not locked', partial: 'LP partly locked', unverifiable: "LP lock can't be verified" }[st] || 'LP lock unknown');
    }
    if (rules.authRevoked) {
      const au = a.auth;
      if (au.mint === undefined || au.freeze === undefined) fails.push('authorities unknown');
      else {
        if (au.mint) fails.push('dev can mint');
        if (au.freeze) fails.push('dev can freeze');
      }
    }
    const t10 = n2(rules.top10Max);
    if (t10 !== null && t10 < 100) {
      if (!a.holders) fails.push('holders unknown');
      else if (a.holders.top10 > t10) fails.push('top 10 hold ' + pct(a.holders.top10, 0));
    }
    const ml = n2(rules.minLiq);
    if (ml && !(c.liquidity >= ml)) fails.push(c.liquidity === null || c.liquidity === undefined ? 'no liquidity data' : 'liquidity ' + usd(c.liquidity));
    const born = c.createdAt || (r.rug && toMs(r.rug.detectedAt)) || null;
    const age = n2(rules.maxAgeH);
    if (age && born && now - born > age * 3600e3) fails.push(dur(now - born) + ' old');
    // Dev rules (full check only)
    const deep = !r.lite;
    if (deep && rules.deep) {
      const L = r.launches;
      const dead = L ? L.items.filter((x) => x.status === 'dead').length : 0;
      const md = n2(rules.maxDeadCoins);
      if (md !== null && dead > md) fails.push('dev has ' + dead + ' dead coins');
      if (r.devFlags && (r.devFlags.labels.length || r.devFlags.malicious)) fails.push('dev flagged as scammer');
      if (a.findings.some((f) => f.group === 'funding' && f.tone === 'bad')) fails.push('funder launched dead coins');
      const mb = n2(rules.maxBundlePct);
      if (mb !== null && r.bundle && r.bundle.state === 'ok' && r.bundle.totalPct > mb) fails.push(pct(r.bundle.totalPct, 0) + ' sniped at launch');
      const mf = n2(rules.maxFresh);
      if (mf !== null && r.holders && r.holders.state === 'ok' && r.holders.fresh > mf) fails.push(r.holders.fresh + ' fresh-wallet holders');
    }
    return {
      pass: !fails.length,
      fails,
      needsDeep: !fails.length && !deep && !!rules.deep,
      score: a.score,
      tone: a.verdict.key === 'rugged' || a.score >= 55 ? 'bad' : a.score >= 25 ? 'warn' : !deep ? 'muted' : 'ok',
      lock: a.lock ? a.lock.state : null,
      deep
    };
  }

  // Compact score for a badge in a coin list (light check: token and market only).
  function badge(r, now) {
    const a = assess(r, now);
    const tone = a.verdict.key === 'rugged' || a.score >= 55 ? 'bad' : a.score >= 25 ? 'warn' : 'neutral';
    return {
      mint: r.mint, input: r.input, symbol: (r.coin && r.coin.symbol) || null,
      score: a.score, tone, lock: a.lock ? a.lock.state : null,
      blacklisted: !!(r.blacklistHits && r.blacklistHits.length),
      top: a.findings.filter((f) => f.tone === 'bad').slice(0, 2).map((f) => f.text)
    };
  }

  // Small, message-safe digest of a report for the on-page button and panel.
  function summary(r, now) {
    now = now || Date.now();
    const a = assess(r, now);
    const st = r.status || {};
    const coreBusy = ['dex', 'rugcheck'].some((k) => !st[k] || st[k].state === 'loading');
    const c = r.coin || {};
    const status = {};
    Object.keys(st).forEach((k) => { status[k] = st[k].state; });
    const NAMES = { dex: 'DexScreener', rugcheck: 'RugCheck', rpc: 'Solana RPC', goplus: 'GoPlus', history: 'Dev scan', x: 'X lookup', funding: 'Funding trace', bundle: 'Sniper check', holders: 'Holder check', copycat: 'Copycat search' };
    return {
      // Sources that failed and matter to the verdict (an X lookup failure just shows in the X tile).
      failed: Object.keys(st).filter((k) => k !== 'x' && st[k].state === 'fail').map((k) => NAMES[k] || k),
      coreFailed: ['dex', 'rugcheck', 'rpc', 'goplus'].some((k) => st[k] && st[k].state === 'fail'),
      mint: r.mint, input: r.input, name: c.name || null, symbol: c.symbol || null,
      score: a.score, verdict: a.verdict, complete: a.complete, coreBusy,
      counts: { bad: a.findings.filter((f) => f.tone === 'bad').length, warn: a.findings.filter((f) => f.tone === 'warn').length },
      flags: a.findings.filter((f) => f.tone === 'bad' || f.tone === 'warn').map((f) => ({ tone: f.tone, text: f.text })),
      facts: quickFacts(r, a, now),
      exit: a.exit,
      creator: r.creator || null,
      // An exchange hot wallet funds thousands of people: never offer to blacklist that.
      funder: (r.funding && r.funding.funder && !r.funding.highVolume) ? r.funding.funder : null,
      blacklisted: (r.blacklistHits || []).map((h) => h.role),
      status
    };
  }

  // ---------- API client ----------
  function createClient(opts) {
    opts = opts || {};
    const fetchImpl = opts.fetch || function () { return root.fetch.apply(root, arguments); };
    const rpcs = (opts.rpcUrl ? [opts.rpcUrl] : []).concat(DEFAULT_RPCS);
    const scanPause = opts.scanPause === undefined ? SCAN_PAUSE_MS : opts.scanPause;
    let rpcIndex = 0;

    // `accept` lists error statuses whose JSON body we still want (e.g. 404 "User is suspended").
    async function getJSON(url, init, timeout, accept) {
      const ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
      const timer = ctrl ? setTimeout(() => ctrl.abort(), timeout || 15000) : null;
      try {
        const res = await fetchImpl(url, Object.assign({}, init || {}, ctrl ? { signal: ctrl.signal } : {}));
        if (!res.ok && accept && accept.indexOf(res.status) >= 0) {
          try { return await res.json(); } catch (e) { return { code: res.status }; }
        }
        if (!res.ok) { const e = new Error('HTTP ' + res.status); e.status = res.status; throw e; }
        return await res.json();
      } catch (e) {
        if (e && e.name === 'AbortError') throw new Error('timed out');
        throw e;
      } finally { if (timer) clearTimeout(timer); }
    }

    // All Solana network calls go through a small queue: free public nodes refuse bursts,
    // and the newer checks make a lot of calls. A rate-limited call is retried once after a pause.
    const rpcMax = opts.rpcConcurrency || 4;
    const rpcGap = opts.rpcGap === undefined ? 40 : opts.rpcGap;
    let rpcActive = 0;
    let rpcNextStart = 0;
    const rpcWaiters = [];
    async function rpcSlot() {
      while (rpcActive >= rpcMax) await new Promise((r) => rpcWaiters.push(r));
      rpcActive++;
      const now = Date.now();
      const startAt = Math.max(now, rpcNextStart);
      rpcNextStart = startAt + rpcGap;
      if (startAt > now) await sleep(startAt - now);
    }
    function rpcRelease() {
      rpcActive--;
      const w = rpcWaiters.shift();
      if (w) w();
    }
    const limited = (e) => e && (e.status === 429 || e.rpcCode === 429 || e.rpcCode === -32429 || e.rpcCode === -32005);
    async function rpc(method, params) {
      await rpcSlot();
      try {
        try { return await rpcOnce(method, params); }
        catch (e) {
          if (!limited(e)) throw e;
          await sleep(rpcGap ? 900 : 0);
          return await rpcOnce(method, params);
        }
      } finally { rpcRelease(); }
    }

    async function rpcOnce(method, params) {
      let last;
      for (let i = 0; i < rpcs.length; i++) {
        const idx = (rpcIndex + i) % rpcs.length;
        try {
          const body = await getJSON(rpcs[idx], {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ jsonrpc: '2.0', id: 1, method, params })
          }, 20000);
          if (body && body.error) {
            const e = new Error(body.error.message || 'RPC error');
            e.rpcCode = body.error.code;
            throw e;
          }
          rpcIndex = idx;
          return body ? body.result : null;
        } catch (e) {
          last = e;
          // A real JSON-RPC error (bad params etc.) won't change on another node.
          if (e.rpcCode !== undefined && e.rpcCode !== 429 && e.rpcCode !== -32005 && e.rpcCode !== -32429) throw e;
        }
      }
      throw last;
    }

    async function dexTokens(mints) {
      const out = [];
      for (let i = 0; i < mints.length; i += 30) {
        const chunk = mints.slice(i, i + 30);
        const r = await getJSON(DEX + '/tokens/v1/solana/' + chunk.join(','));
        if (Array.isArray(r)) out.push.apply(out, r);
      }
      return out;
    }

    async function feed(kind) {
      const path = kind === 'trending' ? '/token-boosts/top/v1' : '/token-profiles/latest/v1';
      const raw = await getJSON(DEX + path);
      const seen = new Set();
      const items = (Array.isArray(raw) ? raw : [raw]).filter((x) => {
        if (!x || x.chainId !== 'solana' || !x.tokenAddress || seen.has(x.tokenAddress)) return false;
        seen.add(x.tokenAddress);
        return true;
      }).slice(0, 30);
      if (!items.length) return [];
      const best = bestPairs(await dexTokens(items.map((x) => x.tokenAddress)));
      return items.map((x) => coinFromPair(best.get(x.tokenAddress), { mint: x.tokenAddress, icon: x.icon }));
    }

    async function search(q) {
      q = String(q || '').trim();
      if (!q) return [];
      if (isAddress(q)) {
        const r = { mint: q, pairs: [] };
        await loadMarket(r);
        return [r.coin];
      }
      const res = await getJSON(DEX + '/latest/dex/search?q=' + encodeURIComponent(q));
      const best = bestPairs(res && res.pairs);
      return Array.from(best.values()).sort((a, b) => liqOf(b) - liqOf(a)).slice(0, 30).map((p) => coinFromPair(p));
    }

    // Market data for r.mint. If the address is a pool rather than a token, switch r.mint to the token.
    async function loadMarket(r) {
      let pairs = await getJSON(DEX + '/tokens/v1/solana/' + r.mint);
      pairs = (Array.isArray(pairs) ? pairs : []).filter((p) => p && p.baseToken && p.baseToken.address === r.mint);
      if (!pairs.length) {
        const pr = await getJSON(DEX + '/latest/dex/pairs/solana/' + r.mint).catch(() => null);
        const pp = pr ? (pr.pairs || (pr.pair ? [pr.pair] : [])) : [];
        if (pp && pp.length && pp[0] && pp[0].baseToken && pp[0].baseToken.address) {
          r.mint = pp[0].baseToken.address;
          r.resolvedFromPool = true;
          const again = await getJSON(DEX + '/tokens/v1/solana/' + r.mint).catch(() => []);
          pairs = (Array.isArray(again) ? again : []).filter((p) => p && p.baseToken && p.baseToken.address === r.mint);
          if (!pairs.length) pairs = pp;
        }
      }
      r.pairs = pairs.filter((p) => p.chainId === 'solana').sort((a, b) => liqOf(b) - liqOf(a));
      r.coin = coinFromPair(r.pairs[0], { mint: r.mint });
      return r;
    }

    // ----- X account -----
    async function tokenMetadata(r) {
      let fromRc = null;
      try {
        fromRc = await getJSON(RUG + '/v1/tokens/' + r.mint + '/metadata', {}, 10000);
        if (metaLinks(fromRc).twitter) return fromRc;
      } catch (e) { /* fall back to the metadata file itself */ }
      const tm = r.rug && ((r.rug.tokenMeta && r.rug.tokenMeta.uri) ||
        (r.rug.token_extensions && r.rug.token_extensions.tokenMetadata && r.rug.token_extensions.tokenMetadata.uri));
      let uri = typeof tm === 'string' ? tm.trim() : '';
      if (/^ipfs:\/\//i.test(uri)) uri = 'https://ipfs.io/ipfs/' + uri.slice(7);
      if (/^ar:\/\//i.test(uri)) uri = 'https://arweave.net/' + uri.slice(5);
      if (!/^https:\/\//i.test(uri)) return fromRc;
      try { return await getJSON(uri, {}, 10000); } catch (e) { return fromRc; }
    }

    async function findXLink(r) {
      for (const p of r.pairs || []) {
        const s = ((p.info && p.info.socials) || []).find((s) => s && /^(twitter|x)$/i.test(s.type || s.platform || ''));
        if (s && (s.url || s.handle)) return { url: s.url || s.handle, source: 'DexScreener', extra: {} };
      }
      const m = metaLinks(await tokenMetadata(r));
      return { url: m.twitter, source: m.twitter ? 'token metadata' : null, extra: { website: m.website, telegram: m.telegram } };
    }

    async function fxUser(handle) {
      const j = await getJSON(FX + '/' + encodeURIComponent(handle), {}, 12000, [401, 404]);
      if (j && j.user) {
        const user = normalizeXUser(j.user);
        if (user) return { state: 'ok', user };
      }
      const msg = String((j && j.message) || '').toLowerCase();
      if ((j && j.reason === 'suspended') || /suspend/.test(msg)) return { state: 'suspended' };
      if ((j && j.code === 404) || /not found/.test(msg)) return { state: 'notfound' };
      if ((j && j.code === 401) || /private|protected/.test(msg)) return { state: 'private' };
      throw new Error((j && j.message) || 'unexpected reply');
    }

    async function loadX(r) {
      const link = await findXLink(r);
      r.metaLinks = link.extra || {};
      if (!link.url) return { kind: 'none' };
      const p = parseX(link.url);
      if (!p) return { kind: 'invalid', raw: link.url, source: link.source };
      const x = Object.assign({ source: link.source, raw: link.url, state: 'ok' }, p);
      try {
        if (p.kind === 'profile') Object.assign(x, await fxUser(p.handle));
        else if (p.kind === 'tweet') {
          const j = await getJSON(FX + '/status/' + p.id, {}, 12000, [401, 404]);
          const t = j && j.tweet;
          if (!t) { x.state = j && j.code === 401 ? 'private' : 'notfound'; return x; }
          x.tweet = {
            author: t.author && t.author.screen_name,
            createdAt: t.created_timestamp ? t.created_timestamp * 1000 : toMs(t.created_at),
            text: String(t.text || '').slice(0, 280),
            likes: num(t.likes), views: num(t.views)
          };
          if (x.tweet.author) {
            x.handle = x.tweet.author;
            try { const a = await fxUser(x.tweet.author); if (a.user) x.user = a.user; } catch (e) { /* the tweet alone is enough */ }
          }
        }
      } catch (e) {
        x.state = 'error';
        x.error = describeError(e);
      }
      return x;
    }

    // A pool or bonding curve holds the coin in a token account it owns. If it holds exactly one
    // non-SOL/USDC/USDT token, that's the coin. Shared authorities hold many and are left alone.
    async function mintFromPoolAccount(addr) {
      const mints = new Set();
      for (const programId of TOKEN_PROGRAMS) {
        const res = await rpc('getTokenAccountsByOwner', [addr, { programId }, { encoding: 'jsonParsed' }]);
        ((res && res.value) || []).forEach((a) => {
          const info = a && a.account && a.account.data && a.account.data.parsed && a.account.data.parsed.info;
          if (info && info.mint && !QUOTE_MINTS.has(info.mint)) mints.add(info.mint);
        });
      }
      if (mints.size === 1) return Array.from(mints)[0];
      return mintFromRecentTx(addr);
    }

    // Second try for pools whose vaults sit under a shared authority: a recent trade through the pool
    // moves exactly one non-SOL/USDC/USDT token, and that's the coin.
    async function mintFromRecentTx(addr) {
      const sigs = (await rpc('getSignaturesForAddress', [addr, { limit: 6 }])) || [];
      for (const s of sigs.filter((x) => !x.err).slice(0, 3)) {
        const tx = await rpc('getTransaction', [s.signature, { encoding: 'jsonParsed', maxSupportedTransactionVersion: 0 }]);
        const meta = tx && tx.meta;
        if (!meta) continue;
        const mints = new Set([].concat(meta.postTokenBalances || [], meta.preTokenBalances || [])
          .map((b) => b && b.mint).filter((m) => m && !QUOTE_MINTS.has(m)));
        if (mints.size === 1) return Array.from(mints)[0];
      }
      return null;
    }

    // Fee payer of the token's very first transaction. Only used when RugCheck is down.
    async function findCreator(mint) {
      let before;
      for (let page = 0; page < 3; page++) {
        const sigs = await rpc('getSignaturesForAddress', [mint, before ? { limit: 1000, before } : { limit: 1000 }]);
        if (!sigs || !sigs.length) return null;
        const oldest = sigs[sigs.length - 1];
        if (sigs.length < 1000) {
          const tx = await rpc('getTransaction', [oldest.signature, { encoding: 'jsonParsed', maxSupportedTransactionVersion: 0 }]);
          const keys = tx && tx.transaction && tx.transaction.message && tx.transaction.message.accountKeys;
          return keys && keys.length ? keyOf(keys[0]) : null;
        }
        before = oldest.signature;
      }
      return null; // too busy to reach the first transaction cheaply
    }

    async function walletInfo(addr) {
      const sigs = (await rpc('getSignaturesForAddress', [addr, { limit: 1000 }])) || [];
      const bal = await rpc('getBalance', [addr]).catch(() => null);
      const times = sigs.map((s) => s.blockTime).filter(Boolean);
      return {
        txCount: sigs.length,
        capped: sigs.length >= 1000,
        firstSeen: times.length ? Math.min.apply(null, times) * 1000 : null,
        lastSeen: times.length ? Math.max.apply(null, times) * 1000 : null,
        sol: bal && typeof bal.value === 'number' ? bal.value / LAMPORTS : null,
        sigs
      };
    }

    async function devFlags(addr) {
      const j = await getJSON(GOPLUS + '/api/v1/address_security/' + addr + '?chain_id=solana');
      if (!j || (String(j.code) !== '1' && String(j.code) !== '2')) throw new Error((j && j.message) || 'no result');
      const res = j.result || {};
      return {
        labels: Object.keys(FLAG_LABELS).filter((k) => String(res[k]) === '1').map((k) => FLAG_LABELS[k]),
        malicious: parseInt(res.number_of_malicious_contracts_created, 10) || 0
      };
    }

    // ----- funding trail: where did the dev's SOL come from? -----
    // Serial ruggers use a fresh wallet per coin but fund them from the same place. A fresh wallet's
    // oldest transaction is almost always the transfer that funded it.
    async function traceFunding(r) {
      const w = r.wallet;
      if (!w || !w.sigs || !w.sigs.length) return { state: 'skipped', note: 'no wallet history' };
      if (w.capped) return { state: 'skipped', note: 'dev wallet too active to trace (1,000+ transactions)' };
      const oldest = w.sigs.slice(-3).reverse();
      let found = null;
      for (const s of oldest) {
        const tx = await rpc('getTransaction', [s.signature, { encoding: 'jsonParsed', maxSupportedTransactionVersion: 0 }]);
        if (!tx) continue;
        const ins = solTransfers(tx).filter((t) => t.to === r.creator && t.from && t.from !== r.creator).sort((a, b) => b.lamports - a.lamports);
        if (ins.length) { found = { funder: ins[0].from, lamports: ins[0].lamports, at: (tx.blockTime || s.blockTime || 0) * 1000 || null, via: 'transfer' }; break; }
        // Fallback: someone else paid for a transaction that raised the dev's SOL balance.
        const keys = (tx.transaction.message.accountKeys || []).map(keyOf);
        const idx = keys.indexOf(r.creator);
        const pre = tx.meta && tx.meta.preBalances;
        const post = tx.meta && tx.meta.postBalances;
        if (keys[0] && keys[0] !== r.creator && idx >= 0 && pre && post && post[idx] > pre[idx]) {
          found = { funder: keys[0], lamports: post[idx] - pre[idx], at: (tx.blockTime || 0) * 1000 || null, via: 'fee payer' };
          break;
        }
      }
      if (!found) return { state: 'ok', funder: null, note: 'no incoming SOL in the wallet\'s first transactions' };
      const out = Object.assign({ state: 'ok', sol: found.lamports / LAMPORTS }, found);
      const fsigs = (await rpc('getSignaturesForAddress', [found.funder, { limit: 1000 }])) || [];
      out.funderTxs = fsigs.length;
      out.highVolume = fsigs.length >= 1000;
      const ft = fsigs.map((s) => s.blockTime).filter(Boolean);
      out.funderFirstSeen = !out.highVolume && ft.length ? Math.min.apply(null, ft) * 1000 : null;
      if (out.highVolume) { out.note = 'high-volume wallet (likely an exchange or service)'; return out; }
      // What else has the funder been up to: coins it launched, wallets it sent SOL to.
      const recent = fsigs.filter((s) => !s.err).slice(0, FUND_SCAN);
      const recips = new Set();
      const launched = [];
      await mapLimit(recent, 3, async (s) => {
        const tx = await rpc('getTransaction', [s.signature, { encoding: 'jsonParsed', maxSupportedTransactionVersion: 0 }]);
        if (!tx) return;
        launchedMints(tx, found.funder).forEach((m) => launched.push({ mint: m, createdAt: (tx.blockTime || 0) * 1000 || null }));
        solTransfers(tx).forEach((t) => { if (t.from === found.funder && t.to && t.to !== found.funder) recips.add(t.to); });
      });
      out.scanned = recent.length;
      out.recipients = recips.size;
      const uniq = launched.filter((l, i) => l.mint !== r.mint && launched.findIndex((x) => x.mint === l.mint) === i);
      if (uniq.length) {
        try {
          const best = bestPairs(await dexTokens(uniq.map((l) => l.mint).slice(0, 30)));
          uniq.forEach((l) => { l.coin = coinFromPair(best.get(l.mint), { mint: l.mint }); l.status = classify(l, Date.now()); });
        } catch (e) { uniq.forEach((l) => { l.status = 'unknown'; }); }
      }
      out.launches = uniq;
      return out;
    }

    // ----- snipers and bundles: who bought in the first second? -----
    async function bundleCheck(r) {
      let page = [];
      let before;
      for (let i = 0; i < 3; i++) {
        const sigs = await rpc('getSignaturesForAddress', [r.mint, before ? { limit: 1000, before } : { limit: 1000 }]);
        if (!sigs || !sigs.length) break;
        page = sigs;
        if (sigs.length < 1000) break;
        if (i === 2) return { state: 'skipped', note: 'too many trades to reach the launch (older coin)' };
        before = sigs[sigs.length - 1].signature;
      }
      if (!page.length) return { state: 'skipped', note: 'no trades yet' };
      const firstSlot = page[page.length - 1].slot;
      const early = page.filter((s) => !s.err && s.slot <= firstSlot + BUNDLE_SLOTS).reverse().slice(0, BUNDLE_TXS);
      const supply = (r.mintInfo && !r.mintInfo.notMint && r.mintInfo.supply) || (r.rug && r.rug.token && num(r.rug.token.supply));
      if (!supply) return { state: 'skipped', note: 'supply unknown' };
      const skip = poolSet(r.rug);
      const bought = new Map();
      const txs = await mapLimit(early, 3, (s) => rpc('getTransaction', [s.signature, { encoding: 'jsonParsed', maxSupportedTransactionVersion: 0 }]));
      txs.forEach((tx) => {
        if (!tx || !tx.meta || tx.meta.err) return;
        const pre = new Map();
        (tx.meta.preTokenBalances || []).forEach((b) => { if (b && b.mint === r.mint) pre.set(b.accountIndex, num(b.uiTokenAmount && b.uiTokenAmount.amount) || 0); });
        (tx.meta.postTokenBalances || []).forEach((b) => {
          if (!b || b.mint !== r.mint || !b.owner || skip.has(b.owner)) return;
          const delta = (num(b.uiTokenAmount && b.uiTokenAmount.amount) || 0) - (pre.get(b.accountIndex) || 0);
          // A single jump over half the supply is the pool or curve being seeded, not a buyer.
          if (delta > 0 && delta < supply * 0.5) bought.set(b.owner, (bought.get(b.owner) || 0) + delta);
        });
      });
      const held = new Map(holderList(r.rug).map((h) => [h.owner, h.pct]));
      const buyers = Array.from(bought.entries()).filter(([o]) => o !== r.creator)
        .map(([owner, raw]) => ({ owner, pct: raw / supply * 100, holdsPct: held.has(owner) ? held.get(owner) : null }))
        .sort((a, b) => b.pct - a.pct);
      return {
        state: 'ok',
        txs: early.length,
        wallets: buyers.length,
        totalPct: buyers.reduce((s, b) => s + b.pct, 0),
        devBuyPct: (bought.get(r.creator) || 0) / supply * 100,
        stillHeldPct: buyers.reduce((s, b) => s + (b.holdsPct || 0), 0),
        buyers: buyers.slice(0, 12),
        launchAt: page[page.length - 1].blockTime ? page[page.length - 1].blockTime * 1000 : null
      };
    }

    // ----- fresh wallets among the top holders -----
    async function freshHolders(r) {
      const list = holderList(r.rug).slice(0, 10);
      if (!list.length) return { state: 'skipped', note: 'no holder list' };
      const now = Date.now();
      const res = await mapLimit(list, 3, async (h) => {
        const s = (await rpc('getSignaturesForAddress', [h.owner, { limit: 100 }])) || [];
        const times = s.map((t) => t.blockTime).filter(Boolean);
        const firstSeen = s.length < 100 && times.length ? Math.min.apply(null, times) * 1000 : null;
        return { owner: h.owner, pct: h.pct, txs: s.length, firstSeen, fresh: firstSeen !== null && now - firstSeen < 24 * 3600e3 };
      });
      const ok = res.filter(Boolean);
      if (!ok.length) throw new Error('holder lookups failed');
      const fresh = ok.filter((x) => x.fresh);
      return { state: 'ok', checked: ok.length, fresh: fresh.length, freshPct: fresh.reduce((s, x) => s + x.pct, 0), list: ok };
    }

    // ----- copycats: other coins with the same ticker or name -----
    async function copycats(r) {
      const c = r.coin || {};
      if (!c.symbol) return { state: 'skipped', note: 'no ticker yet' };
      const res = await getJSON(DEX + '/latest/dex/search?q=' + encodeURIComponent(c.symbol));
      const eq = (a, b) => !!a && !!b && String(a).trim().toLowerCase() === String(b).trim().toLowerCase();
      const same = Array.from(bestPairs(res && res.pairs).values())
        .filter((p) => p.baseToken.address !== r.mint && (eq(p.baseToken.symbol, c.symbol) || eq(p.baseToken.name, c.name)));
      const mc = (p) => num(p.marketCap) || num(p.fdv) || 0;
      const older = same.filter((p) => p.pairCreatedAt && c.createdAt && p.pairCreatedAt < c.createdAt);
      const bigOlder = older.filter((p) => mc(p) > (c.mcap || 0)).sort((a, b) => mc(b) - mc(a))[0];
      return {
        state: 'ok',
        count: same.length,
        original: bigOlder ? coinFromPair(bigOlder) : null,
        isOriginal: same.length > 0 && !older.length,
        others: same.sort((a, b) => mc(b) - mc(a)).slice(0, 5).map((p) => coinFromPair(p))
      };
    }

    // ----- your blacklist -----
    async function blacklistHits(r) {
      if (!opts.blacklist) return [];
      let list = null;
      try { list = await opts.blacklist(); } catch (e) { return []; }
      if (!list || typeof list !== 'object') return [];
      const hits = [];
      const seen = new Set();
      const check = (addr, role) => {
        if (addr && list[addr] && !seen.has(addr)) { seen.add(addr); hits.push({ addr, role, note: list[addr].note || '', at: list[addr].at || null }); }
      };
      check(r.mint, 'coin');
      check(r.creator, 'dev');
      check(r.funding && r.funding.funder, 'funder');
      ((r.bundle && r.bundle.buyers) || []).forEach((b) => check(b.owner, 'sniper'));
      holderList(r.rug).forEach((h) => check(h.owner, 'holder'));
      return hits;
    }

    // ----- light check for list badges and the filtered feed: market + token report only -----
    async function lite(input) {
      input = String(input || '').trim();
      if (!isAddress(input)) throw new Error('not an address');
      const r = { input, mint: input, status: {}, coin: coinFromPair(null, { mint: input }), pairs: [], rug: null, mintInfo: null, lite: true, exitSize: opts.exitSize || 1 };
      try { await loadMarket(r); r.status.dex = { state: 'ok', note: '' }; }
      catch (e) { r.status.dex = { state: 'fail', note: describeError(e) }; }
      try {
        r.rug = await getJSON(RUG + '/v1/tokens/' + r.mint + '/report', {}, 20000);
        r.status.rugcheck = { state: 'ok', note: '' };
      } catch (e) {
        if (isNoReport(e)) r.rugMissing = true;
        r.status.rugcheck = { state: isNoReport(e) ? 'skip' : 'fail', note: describeError(e) };
      }
      if (r.rug && r.rug.token && num(r.rug.token.supply) > 0 && num(r.rug.creatorBalance) !== null) {
        r.creatorPct = num(r.rug.creatorBalance) / num(r.rug.token.supply) * 100;
      }
      r.creator = (r.rug && r.rug.creator) || null;
      r.blacklistHits = await blacklistHits(r);
      return r;
    }

    function mergeLaunches(r, list) {
      const L = r.launches;
      list.forEach((t) => {
        if (!t || !t.mint) return;
        if (t.mint === r.mint) { L.foundCurrent = true; return; }
        const cur = L.items.find((x) => x.mint === t.mint);
        if (cur) {
          if (t.createdAt && (!cur.createdAt || t.createdAt < cur.createdAt)) cur.createdAt = t.createdAt;
          if (cur.source.indexOf(t.source) < 0) cur.source += ' + ' + t.source;
        } else {
          L.items.push({ mint: t.mint, createdAt: t.createdAt || null, source: t.source, coin: null, status: 'unknown' });
        }
      });
    }

    async function enrichLaunches(r, now) {
      const L = r.launches;
      if (!L.items.length) return;
      const best = bestPairs(await dexTokens(L.items.map((x) => x.mint).slice(0, 90)));
      L.items.forEach((it) => {
        it.coin = coinFromPair(best.get(it.mint), { mint: it.mint });
        it.status = classify(it, now || Date.now());
      });
      L.items.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
    }

    async function scanLaunches(creator, sigs, onProgress) {
      const queue = sigs.slice();
      const found = [];
      let done = 0;
      let failures = 0;
      const worker = async () => {
        while (queue.length) {
          const s = queue.shift();
          try {
            const tx = await rpc('getTransaction', [s.signature, { encoding: 'jsonParsed', maxSupportedTransactionVersion: 0 }]);
            launchedMints(tx, creator).forEach((m) => found.push({ mint: m, createdAt: ((tx && tx.blockTime) || s.blockTime || 0) * 1000 || null }));
          } catch (e) { failures++; }
          done++;
          if (onProgress) onProgress(done);
          if (scanPause) await sleep(scanPause);
        }
      };
      const n = Math.min(SCAN_WORKERS, queue.length);
      const workers = [];
      for (let i = 0; i < n; i++) workers.push(worker());
      await Promise.all(workers);
      return { found, done, failures };
    }

    // Scan the next `count` of the dev's transactions for coins they created.
    async function scanMore(r, count, onUpdate) {
      const emit = () => { if (onUpdate) try { onUpdate(r); } catch (e) { /* UI errors stay in the UI */ } };
      const L = r.launches;
      if (!L || !r.wallet) return r;
      const sigs = r.wallet.sigs.filter((s) => !s.err);
      const batch = sigs.slice(L.nextOffset, L.nextOffset + count);
      L.nextOffset += batch.length;
      if (batch.length) {
        L.progress = { done: 0, total: batch.length };
        r.status.history = { state: 'loading', note: '' };
        emit();
        const res = await scanLaunches(r.creator, batch, (d) => { L.progress.done = d; emit(); });
        L.scanned += batch.length;
        L.failures += res.failures;
        mergeLaunches(r, res.found.map((f) => Object.assign(f, { source: 'wallet scan' })));
      }
      L.progress = null;
      try {
        await enrichLaunches(r);
        r.status.history = L.failures > L.scanned / 2
          ? { state: 'fail', note: 'many transactions failed to load' }
          : { state: 'ok', note: L.scanned ? plural(L.scanned, 'tx') + ' scanned' : '' };
      } catch (e) {
        r.status.history = { state: 'fail', note: describeError(e) };
      }
      emit();
      return r;
    }

    async function inspect(input, onUpdate) {
      input = String(input || '').trim();
      if (!isAddress(input)) throw new Error("That doesn't look like a Solana address.");
      const r = {
        input, mint: input, status: {}, coin: coinFromPair(null, { mint: input }), pairs: [],
        rug: null, mintInfo: null, creator: null, creatorSource: null, creatorPct: null,
        wallet: null, devFlags: null, launches: null, rpcError: null,
        funding: null, bundle: null, holders: null, copycats: null, blacklistHits: [], exitSize: opts.exitSize || 1
      };
      const emit = () => { if (onUpdate) try { onUpdate(r); } catch (e) { /* ignore */ } };
      const mark = (k, state, note) => { r.status[k] = { state, note: note || '' }; emit(); };

      // 1 + 2. Market data, token report and on-chain mint account, all started at once.
      // Most links are the token itself; if it turns out to be a pool, the report is fetched again for the token.
      mark('dex', 'loading');
      mark('rugcheck', 'loading');
      mark('rpc', 'loading');
      const settle = (p) => p.then((v) => ({ ok: true, v }), (e) => ({ ok: false, e }));
      const fetchRug = (mint) => settle(getJSON(RUG + '/v1/tokens/' + mint + '/report', {}, 25000));
      const fetchAcc = (mint) => settle(rpc('getAccountInfo', [mint, { encoding: 'jsonParsed' }]));
      let rugP = fetchRug(input);
      let accP = fetchAcc(input);
      let dexErr = null;
      try { await loadMarket(r); } catch (e) { dexErr = e; }
      if (r.mint !== input) {
        rugP = fetchRug(r.mint);
        accP = fetchAcc(r.mint);
      } else if (!r.pairs.length) {
        // Not on DexScreener yet (e.g. a brand-new coin opened from Axiom or Photon by its pool address):
        // ask the chain which coin that pool holds. Wallets (owned by the System Program) are skipped.
        const first = await accP;
        const acc = first.ok ? parseMintAccount(first.v) : null;
        if (acc && acc.notMint && acc.owner && acc.owner !== SYSTEM_PROGRAM) {
          try {
            const m = await mintFromPoolAccount(r.mint);
            if (m) {
              r.mint = m;
              r.coin = coinFromPair(null, { mint: m });
              try { await loadMarket(r); dexErr = null; } catch (e) { dexErr = e; }
              r.resolvedFromPool = true;
              rugP = fetchRug(m);
              accP = fetchAcc(m);
            }
          } catch (e) { /* RPC trouble is reported by the checks below */ }
        }
      }
      if (dexErr) mark('dex', 'fail', describeError(dexErr));
      else mark('dex', 'ok', r.pairs.length ? plural(r.pairs.length, 'pool') : 'no pool yet');
      await Promise.all([
        rugP.then((res) => {
          if (res.ok) { r.rug = res.v; mark('rugcheck', 'ok'); }
          // 4xx = RugCheck answered "I have no report for that address": not an outage.
          else if (isNoReport(res.e)) { r.rugMissing = true; mark('rugcheck', 'skip', 'no report for this address'); }
          else mark('rugcheck', 'fail', describeError(res.e));
        }),
        accP.then((res) => { if (res.ok) r.mintInfo = parseMintAccount(res.v); else r.rpcError = describeError(res.e); })
      ]);
      const notToken = r.mintInfo && (r.mintInfo.notMint || r.mintInfo.missing);
      if (!r.pairs.length && (notToken || (!r.rug && !r.mintInfo))) {
        mark('rpc', r.rpcError ? 'fail' : 'ok', r.rpcError || '');
        let msg, kind;
        if (r.mintInfo && r.mintInfo.notMint && r.mintInfo.owner === SYSTEM_PROGRAM) {
          kind = 'wallet'; msg = "That's a wallet address, not a coin. Open the coin's own page, or paste its contract address.";
        } else if (r.mintInfo && r.mintInfo.notMint) {
          kind = 'pool'; msg = "That looks like a pool or program address, and the coin behind it couldn't be traced yet. Paste the coin's contract address instead.";
        } else if (r.mintInfo && r.mintInfo.missing) {
          kind = 'missing'; msg = 'No Solana token exists at that address.';
        } else {
          kind = 'unreachable'; msg = "Couldn't reach RugCheck or the Solana network. Try again in a minute.";
        }
        const err = new Error(msg);
        err.kind = kind;
        err.report = r;
        throw err;
      }
      if (r.rug && r.rug.token && num(r.rug.token.supply) > 0 && num(r.rug.creatorBalance) !== null) {
        r.creatorPct = num(r.rug.creatorBalance) / num(r.rug.token.supply) * 100;
      }

      // The coin's X account runs alongside the dev checks.
      mark('x', 'loading');
      const xPart = loadX(r).then((x) => {
        r.x = x;
        if (x.kind === 'none') mark('x', 'skip', 'no X link');
        else if (x.state === 'error') mark('x', 'fail', x.error);
        else mark('x', 'ok');
      }, (e) => { r.x = null; mark('x', 'fail', describeError(e)); });

      const devPart = async () => {
        // 3. Who launched it
        r.creator = (r.rug && r.rug.creator) || null;
        r.creatorSource = r.creator ? 'RugCheck' : null;
        if (!r.creator) {
          try {
            r.creator = await findCreator(r.mint);
            r.creatorSource = r.creator ? "the token's first transaction" : null;
          } catch (e) { r.rpcError = describeError(e); }
        }
        if (!r.creator) {
          mark('rpc', r.rpcError ? 'fail' : 'ok', r.rpcError || 'dev wallet not found');
          mark('goplus', 'skip', 'no dev wallet');
          return;
        }

        // 4. Dev wallet history + scam flags
        mark('goplus', 'loading');
        await Promise.all([
          walletInfo(r.creator).then((w) => { r.wallet = w; }, (e) => { r.rpcError = describeError(e); }),
          devFlags(r.creator).then((f) => { r.devFlags = f; mark('goplus', 'ok'); }, (e) => mark('goplus', 'fail', describeError(e)))
        ]);
        mark('rpc', r.wallet ? 'ok' : 'fail', r.wallet ? '' : r.rpcError);

        // 5. The dev's other coins: RugCheck's creator history + a scan of the dev's own transactions
        r.launches = {
          items: [], scanned: 0, failures: 0, nextOffset: 0, progress: null, foundCurrent: false,
          total: r.wallet ? r.wallet.sigs.filter((s) => !s.err).length : 0, fromRugcheck: 0
        };
        const fromRc = normalizeCreatorTokens(r.rug && r.rug.creatorTokens).map((t) => Object.assign(t, { source: 'RugCheck' }));
        mergeLaunches(r, fromRc);
        r.launches.fromRugcheck = fromRc.filter((t) => t.mint !== r.mint).length;
        if (r.wallet) await scanMore(r, AUTO_SCAN, onUpdate);
        else if (r.launches.items.length) {
          try { await enrichLaunches(r); r.status.history = { state: 'ok', note: '' }; }
          catch (e) { r.status.history = { state: 'fail', note: describeError(e) }; }
          emit();
        }

        // 6. Who funded the dev
        if (r.wallet) {
          mark('funding', 'loading');
          try {
            r.funding = await traceFunding(r);
            mark('funding', r.funding.state === 'skipped' ? 'skip' : 'ok', r.funding.note || '');
          } catch (e) { r.funding = { state: 'error', note: describeError(e) }; mark('funding', 'fail', describeError(e)); }
        }
      };

      // Side checks that only need the token: launch snipers, fresh holders, copycats.
      const side = (key, field, fn) => {
        mark(key, 'loading');
        return fn(r).then((v) => {
          r[field] = v;
          mark(key, v.state === 'skipped' ? 'skip' : 'ok', v.note || '');
        }, (e) => { r[field] = { state: 'error', note: describeError(e) }; mark(key, 'fail', describeError(e)); });
      };
      const sideParts = [
        side('bundle', 'bundle', bundleCheck),
        r.rug ? side('holders', 'holders', freshHolders) : Promise.resolve(),
        side('copycat', 'copycats', copycats)
      ];

      await Promise.all([devPart(), xPart].concat(sideParts));
      r.blacklistHits = await blacklistHits(r);
      emit();
      return r;
    }

    // New coins to run through your filter: DexScreener's new profiles and boosts, plus RugCheck's newest tokens.
    async function candidates(max) {
      max = max || 45;
      const fromRc = getJSON(RUG + '/v1/stats/new_tokens', {}, 15000).then((x) => (Array.isArray(x) ? x : [])
        .map((t) => t && (t.mint || t.address || t.tokenAddress)).filter((m) => isAddress(m)).slice(0, 30), () => []);
      const [fresh, hot, rcMints] = await Promise.all([feed('new').catch(() => []), feed('trending').catch(() => []), fromRc]);
      const out = [];
      const seen = new Set();
      const push = (c) => { if (c && c.mint && !seen.has(c.mint) && out.length < max) { seen.add(c.mint); out.push(c); } };
      const rcNew = rcMints.filter((m) => !seen.has(m));
      fresh.forEach(push);
      if (rcNew.length) {
        let best = new Map();
        try { best = bestPairs(await dexTokens(rcNew)); } catch (e) { /* show them without market data */ }
        rcNew.forEach((m) => push(coinFromPair(best.get(m), { mint: m })));
      }
      hot.forEach(push);
      if (!out.length) throw new Error('No coin lists answered. Check your connection.');
      return out;
    }

    // Re-check a finished report against the current blacklist (after you add or remove someone).
    async function refreshBlacklist(r) {
      r.blacklistHits = await blacklistHits(r);
      return r;
    }

    return { feed, search, candidates, inspect, lite, scanMore, refreshBlacklist, getJSON, rpc, dexTokens };
  }

  return {
    createClient, assess, quickFacts, summary, badge, exitCheck, filterCheck, DEFAULT_RULES, holderList, solTransfers, classify, launchedMints, holderStats, mainLp, liquidityLock, poolName, authorities, parseMintAccount,
    normalizeCreatorTokens, coinFromPair, bestPairs, isAddress, describeError, parseX, metaLinks, normalizeXUser, toMs,
    usd, pct, signedPct, dur, ago, short, plural, count, AUTO_SCAN
  };
});
