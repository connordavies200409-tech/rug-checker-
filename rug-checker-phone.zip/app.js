/* Rug Checker UI. Works as a normal web page and as the Chrome extension's page. */
(function () {
  'use strict';
  const RC = window.RugCore;
  const $ = (s) => document.querySelector(s);
  const isExt = !!(window.chrome && chrome.runtime && chrome.runtime.id);

  const store = {
    get(k, d) { try { const v = localStorage.getItem(k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* storage off: fine */ } }
  };

  // Settings shared with the extension (chrome.storage) or kept on this device (localStorage on the phone page).
  const useChrome = isExt && !!(chrome.storage && chrome.storage.local);
  const prefs = {
    async get(k, d) {
      if (useChrome) { try { const v = (await chrome.storage.local.get(k))[k]; return v === undefined ? d : v; } catch (e) { /* fall back */ } }
      return store.get('rc.' + k, d);
    },
    async set(k, v) {
      if (useChrome) { try { await chrome.storage.local.set({ [k]: v }); return; } catch (e) { /* fall back */ } }
      store.set('rc.' + k, v);
    }
  };
  const settings = { exitSize: 1, black: {} };
  function makeClient() {
    return RC.createClient({
      rpcUrl: store.get('rc.rpc', '') || undefined,
      exitSize: settings.exitSize,
      blacklist: () => prefs.get('blacklist', {})
    });
  }
  let client = makeClient();
  function sendBg(msg) {
    if (!isExt) return Promise.resolve(null);
    return new Promise((resolve) => {
      try { chrome.runtime.sendMessage(msg, (res) => { void chrome.runtime.lastError; resolve(res || null); }); }
      catch (e) { resolve(null); }
    });
  }

  const el = {
    home: $('#home'), report: $('#report'), list: $('#list'), listMsg: $('#listMsg'),
    form: $('#searchForm'), q: $('#q'), recent: $('#recent'), recentWrap: $('#recentWrap'),
    tabs: Array.from(document.querySelectorAll('[data-feed]')), tabSearch: $('#tab-search'),
    refresh: $('#refresh'), rpcForm: $('#rpcForm'), rpcInput: $('#rpcUrl'), rpcMsg: $('#rpcMsg'),
    homeLink: $('#homeLink'), rules: $('#rules'), filterStatus: $('#filterStatus'),
    exitSize: $('#exitSize'), badgeSet: $('#badgeSet'), badgesOn: $('#badgesOn'), watchSet: $('#watchSet'), watchList: $('#watchList'),
    blackList: $('#blackList'), blackAddr: $('#blackAddr'), blackImport: $('#blackImport'), blackMsg: $('#blackMsg')
  };

  const state = {
    feed: 'new', lists: {}, lastSearch: '', current: null, token: 0, scanning: false, stamped: false,
    lastFinal: false, watching: false, actNote: '',
    filter: { runId: 0, running: false, items: [], res: new Map(), done: 0, total: 0, deepDone: 0, deepTotal: 0, at: 0, error: null, showOuts: false }
  };

  // ---------- helpers ----------
  const esc = (s) => String(s === null || s === undefined ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const safeUrl = (u) => (typeof u === 'string' && /^https:\/\/[^\s"'<>]+$/i.test(u) ? u : '');
  const link = (href, text) => { const u = safeUrl(href); return u ? '<a href="' + esc(u) + '" target="_blank" rel="noopener noreferrer">' + esc(text) + '</a>' : ''; };
  const coinLabel = (c) => (c && c.symbol ? '$' + c.symbol : RC.short(c && c.mint));
  function icon(c, size) {
    const u = safeUrl(c && c.icon);
    const cls = 'ico' + (size ? ' ' + size : '');
    const letter = esc(((c && (c.symbol || c.name)) || '?').charAt(0).toUpperCase());
    return u ? '<img class="' + cls + '" src="' + esc(u) + '" alt="" loading="lazy" referrerpolicy="no-referrer" data-letter="' + letter + '">' : '<span class="' + cls + '" aria-hidden="true">' + letter + '</span>';
  }
  // Swap broken token images for a letter badge (no inline handlers: extension CSP forbids them).
  document.addEventListener('error', (e) => {
    const t = e.target;
    if (t && t.tagName === 'IMG' && t.classList.contains('ico')) {
      const s = document.createElement('span');
      s.className = t.className;
      s.textContent = t.getAttribute('data-letter') || '?';
      s.setAttribute('aria-hidden', 'true');
      t.replaceWith(s);
    }
  }, true);

  function setHash(addr) {
    try { history.replaceState(null, '', location.pathname + location.search + (addr ? '#' + addr : '')); } catch (e) { /* sandboxed */ }
  }

  // ---------- feed ----------
  function setTabs() {
    el.tabs.forEach((b) => b.setAttribute('aria-selected', String(b.dataset.feed === state.feed)));
  }
  function skeletonList() {
    el.listMsg.hidden = true;
    let h = '';
    for (let i = 0; i < 6; i++) {
      h += '<li><div class="coin" aria-hidden="true"><span class="ico"></span><span class="coin-main"><span class="sk" style="width:' + (40 + (i * 13) % 35) + '%"></span><span class="sk" style="width:30%"></span></span><span class="coin-num"><span class="sk" style="width:52px"></span></span></div></li>';
    }
    el.list.innerHTML = h;
  }
  function listMessage(text) {
    el.list.innerHTML = '';
    el.listMsg.textContent = text;
    el.listMsg.hidden = false;
  }
  function coinRow(c) {
    const ch = c.change1h;
    const meta = [];
    meta.push(c.createdAt ? RC.ago(c.createdAt) : 'not trading yet');
    if (c.liquidity !== null) meta.push('liq ' + RC.usd(c.liquidity));
    return '<li><button type="button" class="coin" data-mint="' + esc(c.mint) + '">' + icon(c) +
      '<span class="coin-main"><span class="coin-name">' + esc(c.name || 'Unnamed coin') + ' <span class="sym">' + esc(coinLabel(c)) + '</span></span>' +
      '<span class="coin-meta">' + esc(meta.join(' · ')) + '</span></span>' +
      '<span class="coin-num"><span class="mc">' + esc(c.mcap !== null ? RC.usd(c.mcap) : '–') + '</span>' +
      (ch !== null ? '<span class="' + (ch > 0 ? 'up' : ch < 0 ? 'down' : '') + '">' + esc(RC.signedPct(ch)) + ' 1h</span>' : '') +
      '</span></button></li>';
  }
  function renderList(items, emptyText) {
    if (!items.length) return listMessage(emptyText || 'No Solana coins in this feed right now. Try the other tab or paste an address above.');
    el.listMsg.hidden = true;
    el.list.innerHTML = items.map(coinRow).join('');
  }
  async function loadFeed(kind, force) {
    state.feed = kind;
    setTabs();
    el.rules.hidden = kind !== 'filtered';
    if (kind === 'filtered') {
      const F = state.filter;
      if (force || (!F.items.length && !F.running)) runFilter();
      else renderFiltered();
      return;
    }
    el.filterStatus.textContent = '';
    if (kind === 'search') return renderList(state.lists.search || [], 'No Solana coins match “' + state.lastSearch + '”.');
    if (state.lists[kind] && !force) return renderList(state.lists[kind]);
    skeletonList();
    try {
      const items = await client.feed(kind);
      state.lists[kind] = items;
      if (state.feed === kind) renderList(items);
    } catch (e) {
      if (state.feed === kind) listMessage("Couldn't load coins from DexScreener (" + RC.describeError(e) + '). Check your connection and tap Refresh.');
    }
  }

  // ---------- recent ----------
  function renderRecent() {
    const items = store.get('rc.recent', []);
    el.recentWrap.hidden = !items.length;
    el.recent.innerHTML = items.map((x) => {
      const tone = { bad: 'bad', warn: 'warn', ok: 'ok' }[x.tone] || 'muted';
      return '<li><button type="button" data-mint="' + esc(x.mint) + '"><span class="pill ' + tone + '">' + esc(x.score !== null && x.score !== undefined ? x.score : '?') + '</span>' + esc(x.label) + '</button></li>';
    }).join('');
  }
  function remember(r, a) {
    const label = coinLabel(r.coin);
    const items = store.get('rc.recent', []).filter((x) => x.mint !== r.mint);
    items.unshift({ mint: r.mint, label, score: a.score, tone: a.verdict.tone, at: Date.now() });
    store.set('rc.recent', items.slice(0, 10));
    renderRecent();
  }

  // ---------- report ----------
  function showHome() {
    state.token++;
    state.current = null;
    el.report.hidden = true;
    el.report.innerHTML = '';
    el.home.hidden = false;
    setHash('');
    renderRecent();
  }
  function showReportView() {
    el.home.hidden = true;
    el.report.hidden = false;
    window.scrollTo(0, 0);
  }

  function cachedReport(addr) {
    if (!isExt) return Promise.resolve(null);
    return new Promise((resolve) => {
      const t = setTimeout(() => resolve(null), 400);
      try {
        chrome.runtime.sendMessage({ type: 'rugchecker:getReport', addr }, (res) => {
          clearTimeout(t);
          void chrome.runtime.lastError; // no worker answer is fine
          // Only reuse a complete result; an incomplete one gets a fresh check here.
          resolve(res && res.report && res.report.status && !res.incomplete ? res.report : null);
        });
      } catch (e) { clearTimeout(t); resolve(null); }
    });
  }

  // A fresh check here updates the on-page button too, so both always show the same verdict.
  function shareWithButton(addr, r) {
    if (!isExt) return;
    try { chrome.runtime.sendMessage({ type: 'rugchecker:putReport', addr, report: r }, () => { void chrome.runtime.lastError; }); } catch (e) { /* no button to update */ }
  }

  async function openCoin(addr) {
    addr = String(addr || '').trim();
    if (!RC.isAddress(addr)) return;
    const my = ++state.token;
    state.stamped = false;
    state.openedAt = Date.now();
    state.scanning = false;
    state.current = null;
    state.watching = false;
    state.actNote = '';
    showReportView();
    if (isExt) sendBg({ type: 'rugchecker:watchList' }).then((res) => {
      if (my !== state.token || !res || !res.list) return;
      const was = state.watching;
      state.watching = !!(res.list[addr] || (state.current && res.list[state.current.mint]));
      if (was !== state.watching && state.current) rerender();
    });
    setHash(addr);
    renderReport({ input: addr, mint: addr, status: {}, pairs: [], coin: RC.coinFromPair(null, { mint: addr }) }, false);
    // In the extension, the on-page button has usually just checked this coin: show that result instantly.
    // A coin the filtered feed already fully checked opens instantly too.
    const fe = state.filter.res.get(addr);
    const cached = fe && fe.r && !fe.r.lite && fe.stage === 'done' ? fe.r : await cachedReport(addr);
    if (cached && my === state.token) {
      state.current = cached;
      if (cached.mint !== addr) setHash(cached.mint);
      remember(cached, renderReport(cached, true));
      return;
    }
    try {
      const r = await client.inspect(addr, (rep) => { if (my === state.token) { state.current = rep; renderReport(rep, false); } });
      if (my !== state.token) return;
      state.current = r;
      if (r.mint !== addr) setHash(r.mint);
      const a = renderReport(r, true);
      remember(r, a);
      shareWithButton(addr, r);
    } catch (e) {
      if (my === state.token) renderError(addr, e);
    }
  }

  function renderError(addr, e) {
    el.report.innerHTML = '<div class="report"><button type="button" class="btn back" data-act="home">← All coins</button>' +
      '<div class="errorbox"><p>' + esc(e && e.message ? e.message : 'Something went wrong.') + '</p>' +
      '<p class="mono">' + esc(addr) + '</p>' +
      '<button type="button" class="btn" data-act="retry" data-mint="' + esc(addr) + '">Try again</button></div></div>';
  }

  const SRC_NAMES = { dex: 'DexScreener', rugcheck: 'RugCheck', rpc: 'Solana RPC', goplus: 'GoPlus', history: 'Dev wallet scan', funding: 'Funding trace', bundle: 'Launch trades', holders: 'Holder ages', copycat: 'Copycat search', x: 'X (FxTwitter)' };
  const withHttps = (u) => (typeof u === 'string' && u.trim() ? (/^https?:\/\//i.test(u.trim()) ? u.trim() : 'https://' + u.trim()) : '');
  const TONE_TAG = { bad: 'Red flag', warn: 'Warning', info: 'Note', good: 'Good sign' };
  const STATUS_PILL = { alive: ['ok', 'Alive'], small: ['warn', 'Small'], dead: ['bad', 'Dead'], new: ['muted', 'Too new'], unknown: ['muted', 'Unknown'] };

  function fact(label, value, note) {
    return '<div><dt>' + esc(label) + '</dt><dd>' + value + (note ? '<span class="note">' + esc(note) + '</span>' : '') + '</dd></div>';
  }
  const sk = (w) => '<span class="sk" style="width:' + (w || 60) + '%"></span>';
  // Values wrapped in .dc "decrypt" the first time they appear for a coin.
  const dc = (text) => '<span class="dc">' + esc(text) + '</span>';
  const decoded = new Set();
  const reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const GLYPHS = '█▓▒░#$%&@*+=/<>01';
  function decrypt(root) {
    root.querySelectorAll('.dc').forEach((el) => {
      const text = el.textContent;
      const key = state.token + '|' + text;
      if (decoded.has(key) || !text.trim()) return;
      decoded.add(key);
      if (reduceMotion) return;
      const start = performance.now();
      const span = Math.min(700, 260 + text.length * 22);
      el.classList.add('decrypting');
      const step = (t) => {
        if (!el.isConnected) return;
        const p = Math.min(1, (t - start) / span);
        const shown = Math.floor(p * text.length);
        let out = text.slice(0, shown);
        for (let i = shown; i < text.length; i++) out += text[i] === ' ' ? ' ' : GLYPHS[(Math.random() * GLYPHS.length) | 0];
        el.textContent = out;
        if (p < 1) requestAnimationFrame(step);
        else { el.textContent = text; el.classList.remove('decrypting'); }
      };
      requestAnimationFrame(step);
    });
  }
  const isBusy = (r, k) => !r.status || !r.status[k] || r.status[k].state === 'loading';

  function rerender() { if (state.current) renderReport(state.current, state.lastFinal); }
  function renderReport(r, final) {
    state.lastFinal = !!final;
    const a = RC.assess(r);
    const c = r.coin || {};
    const st = r.status || {};
    const coreBusy = isBusy(r, 'dex') || isBusy(r, 'rugcheck');
    const busy = !final;
    const now = Date.now();
    let h = '<div class="report">';
    h += '<button type="button" class="btn back" data-act="home">← All coins</button>';

    // --- hero: coin + verdict
    h += '<article class="hero">';
    h += '<div class="fileline"><span>Case file</span><span>' + esc(new Date(state.openedAt || now).toLocaleString(undefined, { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })) + '</span></div>';
    h += '<div class="coin-head">' + icon(c, 'lg') + '<div>';
    h += '<h1 class="ch-name">' + (c.name ? dc(c.name) : esc(coreBusy ? 'Loading…' : 'Unnamed coin')) + ' <span class="sym">' + esc(c.symbol ? '$' + c.symbol : '') + '</span></h1>';
    h += '<div class="addr"><code>' + esc(RC.short(r.mint)) + '</code><button type="button" class="copy" data-copy="' + esc(r.mint) + '">Copy address</button></div>';
    const chips = [];
    const lp = r.rug && r.rug.launchpad && r.rug.launchpad.name;
    if (lp) chips.push(lp);
    if (c.createdAt) chips.push(RC.dur(now - c.createdAt) + ' old');
    if (r.rug && r.rug.totalHolders) chips.push(Number(r.rug.totalHolders).toLocaleString() + ' holders');
    if (r.resolvedFromPool) chips.push('opened from pool address');
    if (chips.length) h += '<div class="chips">' + chips.map((x) => '<span class="chip">' + esc(x) + '</span>').join('') + '</div>';
    h += '</div></div>';

    const bad = a.findings.filter((f) => f.tone === 'bad').length;
    const warn = a.findings.filter((f) => f.tone === 'warn').length;
    let tone, label, scoreText, sum, sub;
    if (coreBusy) {
      tone = 'muted'; label = 'Decrypting'; scoreText = '…'; sum = 'Pulling the token report and market data…'; sub = '';
    } else {
      tone = a.verdict.tone; label = a.verdict.label; scoreText = a.score + '/100 risk';
      // Same rule as the on-page button: a grey or green verdict isn't shown until the check has finished.
      if (busy && (a.verdict.key === 'unknown' || a.verdict.key === 'low')) { tone = 'muted'; label = 'Checking…'; }
      sum = bad || warn ? [bad ? RC.plural(bad, 'red flag') : '', warn ? RC.plural(warn, 'warning') : ''].filter(Boolean).join(' and ') + ' found.' : 'No red flags found in these checks.';
      if (busy) sub = 'Still checking the dev and their other coins. The score can still go up.';
      else if (!a.complete) sub = 'Some checks failed (see Sources below), so treat this as partial.';
      else if (a.verdict.key === 'low') sub = 'That means no common rug signs, not a guarantee. Size your bet accordingly.';
      else sub = '';
    }
    // Risk meter: 20 segments, 5 points each. Scans while loading, fills once when the verdict lands.
    const lit = coreBusy ? 0 : Math.round(a.score / 5);
    let meterCls = 'meter';
    if (coreBusy) meterCls += ' scan';
    else if (!busy && !state.stamped) { meterCls += ' fill'; state.stamped = true; }
    let ticks = '';
    for (let i = 0; i < 20; i++) ticks += '<i style="--i:' + i + '"' + (i < lit ? ' class="on"' : '') + '></i>';
    h += '<div class="verdict tone-' + tone + '" role="group" aria-label="Verdict: ' + esc(label) + ', ' + esc(scoreText) + '">' +
      '<div class="score"><span class="score-n">' + (coreBusy ? '--' : a.score) + '</span><span class="score-of">/100<br>risk</span></div>' +
      '<div class="v-right"><div class="v-label">' + esc(label) + '</div>' +
      '<div class="' + meterCls + '" aria-hidden="true">' + ticks + '</div>' +
      '<p class="verdict-sum">' + esc(sum) + (sub ? '<small>' + esc(sub) + '</small>' : '') + '</p></div></div>';

    // Liquidity lock badge, right under the verdict
    // Instant read: the six things to check before buying
    h += '<div class="tiles">' + RC.quickFacts(r, a, now).map((f) => {
      const t = { bad: 'bad', warn: 'warn', ok: 'ok' }[f.tone] || 'muted';
      return '<div class="tile ' + t + (f.busy ? ' busy' : '') + '"><span class="t-lab">' + esc(f.label) + '</span><span class="t-val">' +
        (f.key === 'lock' && !f.busy && t !== 'muted' ? '<span class="padlock' + (f.open ? ' open' : '') + '" aria-hidden="true"></span>' : '') + esc(f.value) + '</span>' +
        (f.note ? '<span class="t-note">' + esc(f.note) + '</span>' : '') + '</div>';
    }).join('') + '</div>';

    let links = [
      link(c.url || 'https://dexscreener.com/solana/' + r.mint, 'DexScreener'),
      link('https://rugcheck.xyz/tokens/' + r.mint, 'RugCheck'),
      link('https://solscan.io/token/' + r.mint, 'Solscan'),
      /pump$/.test(r.mint) ? link('https://pump.fun/coin/' + r.mint, 'pump.fun') : ''
    ].concat((c.socials || []).slice(0, 4).map((s) => link(s.url, s.label)));
    if (!(c.socials || []).length) {
      // Coins without a paid DexScreener profile: use the links from the token's own metadata.
      const ml = r.metaLinks || {};
      if (r.x && r.x.url) links.push(link(r.x.url, 'X'));
      if (ml.website) links.push(link(withHttps(ml.website), 'Website'));
      if (ml.telegram) links.push(link(withHttps(ml.telegram), 'Telegram'));
    }
    links = links.filter(Boolean);
    h += '<nav class="links" aria-label="Open elsewhere">' + links.join('') + '</nav>';
    h += actionsHTML(r, final);
    h += '</article>';

    // --- findings
    h += '<section class="block"><h2>What we found</h2>';
    if (coreBusy && !a.findings.length) h += '<div>' + sk(80) + sk(65) + sk(72) + '</div>';
    else if (!a.findings.length) h += '<p class="lede">Nothing to report yet.</p>';
    else h += '<ul class="findings">' + a.findings.map((f) => '<li class="finding ' + f.tone + '"><span class="tone-tag">' + TONE_TAG[f.tone] + '</span><span>' + esc(f.text) + '</span></li>').join('') + '</ul>';
    h += '</section>';

    // --- liquidity lock
    h += renderLock(r, a, coreBusy, now);

    // --- the dev
    h += '<section class="block"><h2>The dev</h2>';
    if (!r.creator) {
      if (coreBusy || isBusy(r, 'rpc')) h += '<div>' + sk(70) + sk(50) + '</div>';
      else h += '<p class="lede">Couldn\'t identify the wallet that launched this coin' + (st.rpc && st.rpc.note ? ' (' + esc(st.rpc.note) + ')' : '') + '.</p>';
    } else {
      const w = r.wallet;
      h += '<dl class="facts">';
      h += fact('Dev wallet', '<a href="' + esc('https://solscan.io/account/' + r.creator) + '" target="_blank" rel="noopener noreferrer">' + dc(RC.short(r.creator)) + '</a> <button type="button" class="copy" data-copy="' + esc(r.creator) + '">Copy</button>', 'found via ' + r.creatorSource);
      if (w) {
        if (w.firstSeen) h += fact(w.capped ? 'Active since at least' : 'First used', dc(RC.ago(w.firstSeen, now)), w.capped ? 'older history not loaded' : '');
        h += fact('Transactions', dc(w.capped ? '1,000+' : w.txCount.toLocaleString()));
        if (w.sol !== null) h += fact('SOL balance', dc(w.sol.toFixed(w.sol < 10 ? 3 : 1) + ' SOL'));
      } else if (isBusy(r, 'rpc')) h += fact('Wallet history', sk(70));
      else h += fact('Wallet history', '<span class="pill muted">Unavailable</span>', st.rpc && st.rpc.note);
      if (r.creatorPct !== null && r.creatorPct !== undefined) h += fact('Holds of this coin', esc(RC.pct(r.creatorPct, r.creatorPct < 1 ? 2 : 1)), r.creatorPct === 0 ? 'sold or never bought' : '');
      if (r.devFlags) {
        const f = r.devFlags;
        const flagged = f.labels.length || f.malicious > 0;
        h += fact('Scam flags (GoPlus)', flagged ? '<span class="pill bad">' + esc(f.labels.concat(f.malicious ? [f.malicious + ' malicious contracts'] : []).join(', ')) + '</span>' : '<span class="pill ok">None</span>');
      } else if (isBusy(r, 'goplus')) h += fact('Scam flags (GoPlus)', sk(40));
      else h += fact('Scam flags (GoPlus)', '<span class="pill muted">Unavailable</span>', st.goplus && st.goplus.note);
      h += '</dl>';
      h += '<p class="lede">Full history: ' + link('https://solscan.io/account/' + r.creator, 'Solscan') + ' · ' + link('https://gmgn.ai/sol/address/' + r.creator, 'GMGN') + '</p>';
    }
    h += '</section>';

    // --- dev's other coins
    h += '<section class="block"><h2>Dev\'s other coins</h2>';
    const L = r.launches;
    if (!L) {
      if (!r.creator && !coreBusy && !isBusy(r, 'rpc')) h += '<p class="lede">Needs the dev wallet, which couldn\'t be found.</p>';
      else h += '<div>' + sk(75) + sk(55) + '</div>';
    } else {
      const items = L.items;
      const counts = { dead: 0, small: 0, alive: 0, new: 0, unknown: 0 };
      items.forEach((x) => { counts[x.status] = (counts[x.status] || 0) + 1; });
      if (L.progress) {
        const pctDone = L.progress.total ? Math.round(L.progress.done / L.progress.total * 100) : 0;
        h += '<p class="lede">Reading the dev\'s transactions for coins they created: ' + L.progress.done + ' of ' + L.progress.total + '.</p>';
        h += '<div class="progress" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="' + pctDone + '"><span style="width:' + pctDone + '%"></span></div>';
      }
      if (!L.progress || items.length) {
        if (items.length) {
          h += '<p class="lede">' + esc(RC.plural(items.length, 'other coin')) + ' from this wallet' + (L.scanned ? ' (last ' + RC.plural(L.scanned, 'transaction') + ' scanned' + (L.fromRugcheck ? ', plus RugCheck\'s record' : '') + ')' : '') + '.</p>';
          h += '<div class="tally">' + ['dead', 'small', 'alive', 'new'].filter((k) => counts[k]).map((k) => '<span class="pill ' + STATUS_PILL[k][0] + '">' + counts[k] + ' ' + STATUS_PILL[k][1].toLowerCase() + '</span>').join('') + '</div>';
          h += launchList(items.slice(0, 40), now);
        } else if (!L.progress) {
          h += '<p class="lede">' + (L.scanned ? 'No other coins found in the dev\'s last ' + esc(RC.plural(L.scanned, 'transaction')) + (L.foundCurrent ? ' (this coin\'s launch was found, so the scan worked)' : '') + '.' : 'No other launches on record for this wallet.') + '</p>';
        }
      }
      const remaining = Math.max(0, L.total - L.nextOffset);
      if (!L.progress && r.wallet && remaining > 0) {
        h += '<div><button type="button" class="btn" data-act="scan"' + (state.scanning ? ' disabled' : '') + '>Scan ' + Math.min(100, remaining) + ' older transactions</button></div>';
      }
      h += '<p class="hint">Dead = under $10k market cap and under $2k liquidity, or no market at all. A dead coin isn\'t proof of a rug, but a dev with a trail of them usually is.</p>';
    }
    h += '</section>';

    // --- the edge checks: who funded the dev, launch snipers, fresh holders, exit, copycats
    h += renderFunding(r, now);
    h += renderBundle(r, now);
    h += renderHolderAges(r, now);
    h += renderExit(a, coreBusy);
    h += renderCopycats(r, now);

    // --- X account
    h += renderX(r, now);

    // --- token switches
    h += '<section class="block"><h2>Token switches</h2>';
    if (coreBusy) h += '<div>' + sk(70) + sk(60) + sk(66) + '</div>';
    else {
      const auth = a.auth;
      const sw = (v, offText, onText) => v === undefined ? '<span class="pill muted">Unknown</span>' : v ? '<span class="pill bad">' + onText + '</span>' : '<span class="pill ok">' + offText + '</span>';
      h += '<dl class="facts">';
      h += fact('Mint authority', sw(auth.mint, 'Revoked', 'Dev can mint'));
      h += fact('Freeze authority', sw(auth.freeze, 'Revoked', 'Dev can freeze'));
      if (r.rug && r.rug.tokenMeta) h += fact('Name and image', r.rug.tokenMeta.mutable ? '<span class="pill warn">Changeable</span>' : '<span class="pill ok">Locked</span>');
      const fee = r.rug && r.rug.transferFee ? Number(r.rug.transferFee.pct) : null;
      if (fee !== null) h += fact('Transfer fee', fee > 0 ? '<span class="pill ' + (fee >= 10 ? 'bad' : 'warn') + '">' + esc(RC.pct(fee)) + '</span>' : '<span class="pill ok">None</span>');
      if (a.holders) {
        h += fact('Top 10 holders', esc(RC.pct(a.holders.top10, 1)), 'pools and lockers excluded');
        h += fact('Insider wallets', esc(String(r.rug && r.rug.graphInsidersDetected ? r.rug.graphInsidersDetected : 0)));
      }
      h += '</dl>';
      if (!r.rug) h += '<p class="hint">' + (r.rugMissing ? 'RugCheck has no report for this coin yet' : 'RugCheck didn\'t respond') + ', so only the on-chain switches are shown.</p>';
    }
    h += '</section>';

    // --- market
    h += '<section class="block"><h2>Market</h2>';
    if (isBusy(r, 'dex')) h += '<div>' + sk(60) + sk(50) + '</div>';
    else if (!r.pairs || !r.pairs.length) h += '<p class="lede">No trading pool found on DexScreener' + (st.dex && st.dex.state === 'fail' ? ' (' + esc(st.dex.note) + ')' : '') + '.</p>';
    else {
      h += '<dl class="facts">';
      h += fact('Price', esc(c.priceUsd !== null ? RC.usd(c.priceUsd) : '–'));
      h += fact('Market cap', esc(RC.usd(c.mcap)));
      h += fact('Liquidity', esc(RC.usd(c.liquidity)));
      h += fact('Volume 24h', esc(RC.usd(c.volume24h)));
      if (c.buys24h !== null) h += fact('Buys / sells 24h', esc(c.buys24h.toLocaleString() + ' / ' + (c.sells24h || 0).toLocaleString()));
      h += fact('Change 1h / 24h', '<span class="' + (c.change1h > 0 ? 'up' : c.change1h < 0 ? 'down' : '') + '">' + esc(RC.signedPct(c.change1h)) + '</span> / <span class="' + (c.change24h > 0 ? 'up' : c.change24h < 0 ? 'down' : '') + '">' + esc(RC.signedPct(c.change24h)) + '</span>');
      if (c.createdAt) h += fact('Pool opened', esc(RC.ago(c.createdAt, now)));
      if (c.dexId) h += fact('Trading on', esc(c.dexId) + (r.pairs.length > 1 ? ' <span class="note">+' + (r.pairs.length - 1) + ' more pools</span>' : ''));
      h += '</dl>';
    }
    h += '</section>';

    // --- RugCheck risks verbatim
    const risks = (r.rug && r.rug.risks) || [];
    if (risks.length) {
      h += '<section class="block"><h2>RugCheck notes</h2><ul class="risks">' + risks.map((k) => {
        const t = k.level === 'danger' ? 'bad' : k.level === 'warn' ? 'warn' : 'muted';
        return '<li><span class="pill ' + t + '">' + esc(k.level || 'info') + '</span> <strong>' + esc(k.name) + (k.value ? ' (' + esc(k.value) + ')' : '') + '</strong>' + (k.description ? '<p>' + esc(k.description) + '</p>' : '') + '</li>';
      }).join('') + '</ul></section>';
    }

    // --- sources
    h += '<div class="sources"><span>Sources:</span>' + Object.keys(SRC_NAMES).filter((k) => st[k]).map((k) => {
      const s = st[k];
      return '<span class="src ' + esc(s.state) + '" title="' + esc(s.note || s.state) + '"><span class="dot"></span>' + SRC_NAMES[k] + (s.state === 'fail' ? ': ' + esc(s.note || 'failed') : '') + '</span>';
    }).join('') + '</div>';

    h += '</div>';
    el.report.innerHTML = h;
    decrypt(el.report);
    return a;
  }

  const LOCK_BADGE = {
    locked: ['ok', 'LP locked'],
    partial: ['warn', 'LP partly locked'],
    unlocked: ['bad', 'LP not locked'],
    curve: ['muted', 'Bonding curve'],
    unverifiable: ['warn', "Lock can't be verified"],
    unknown: ['muted', 'Lock unknown']
  };
  function lockBadge(r, a, busy) {
    if (busy) return '<span class="lock-badge muted"><span class="padlock" aria-hidden="true"></span>Checking lock…</span>';
    const L = a.lock;
    if (!L) {
      const why = !r.rug ? (r.rugMissing ? 'no RugCheck report yet' : "RugCheck didn't respond") : 'no pool data';
      return '<span class="lock-badge muted"><span class="padlock" aria-hidden="true"></span>Lock unknown</span><span class="lock-note">' + esc(why) + '</span>';
    }
    const b = LOCK_BADGE[L.state] || LOCK_BADGE.unknown;
    let note = '';
    if ((L.state === 'locked' || L.state === 'partial' || L.state === 'unlocked') && L.lockedPct !== null) note = RC.pct(L.lockedPct, 0) + ' of main pool';
    if (L.state === 'curve') note = "liquidity can't be pulled yet";
    if (L.nextUnlock) note += (note ? ' · ' : '') + 'unlocks in ' + RC.dur(L.nextUnlock - Date.now());
    const open = L.state === 'unlocked' || L.state === 'partial' ? ' open' : '';
    return '<span class="lock-badge ' + b[0] + open + '"><span class="padlock" aria-hidden="true"></span>' + esc(b[1]) + '</span>' + (note ? '<span class="lock-note">' + esc(note) + '</span>' : '');
  }

  function renderLock(r, a, busy, now) {
    let h = '<section class="block"><h2>Liquidity lock</h2>';
    if (busy) return h + '<div>' + sk(70) + sk(50) + '</div></section>';
    const L = a.lock;
    if (!L) {
      return h + '<p class="lede">' + (!r.rug ? (r.rugMissing ? "RugCheck has no report for this coin yet (it may be minutes old), so the lock can't be checked." : "Couldn't check the lock because RugCheck didn't respond. Try again in a minute.") : 'No pool data to check yet.') + '</p></section>';
    }
    const b = LOCK_BADGE[L.state] || LOCK_BADGE.unknown;
    const EXPLAIN = {
      locked: 'The LP tokens for the main pool are burned or held in a lock, so the dev can\'t pull that liquidity.',
      partial: 'Part of the main pool\'s liquidity can still be withdrawn by whoever holds the LP tokens.',
      unlocked: 'Most of the main pool\'s liquidity can be withdrawn at any time. This is how a classic rug pull happens.',
      curve: 'The coin hasn\'t graduated yet. Its liquidity sits in the launchpad\'s bonding curve, which nobody can withdraw. Check again after it migrates to a real pool.',
      unverifiable: 'Concentrated-liquidity pools (Meteora DLMM, Orca, Raydium CLMM) hold liquidity in positions, not LP tokens, so a lock can\'t be confirmed here. Treat it as withdrawable.',
      unknown: 'RugCheck didn\'t report a lock figure for the main pool.'
    };
    h += '<p class="lede">' + esc(EXPLAIN[L.state] || '') + '</p>';
    h += '<dl class="facts">';
    h += fact('Status', '<span class="pill ' + b[0] + '">' + esc(b[1]) + '</span>');
    if (!L.main.curve && !L.main.clmm && L.lockedPct !== null) h += fact('Main pool locked', esc(RC.pct(L.lockedPct, 0)), RC.poolName(L.main.type) + ' · ' + RC.usd(L.main.usd));
    else h += fact('Main pool', esc(RC.poolName(L.main.type)), RC.usd(L.main.usd));
    if (L.totalUSD && L.pools.length > 1) h += fact('All lockable pools', esc(RC.usd(L.lockedUSD) + ' of ' + RC.usd(L.totalUSD)), 'locked or burned');
    if (L.timeLocks.length) {
      L.timeLocks.slice(0, 3).forEach((t) => {
        const when = t.unlockAt ? 'unlocks ' + new Date(t.unlockAt).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' }) + ' (in ' + RC.dur(t.unlockAt - now) + ')' : 'no unlock date';
        const soon = t.unlockAt && t.unlockAt - now < 7 * 24 * 3600e3;
        h += fact(t.name, (soon ? '<span class="pill bad">Expiring</span> ' : '') + esc(RC.usd(t.usd)), when);
      });
    } else if (L.state === 'locked') {
      h += fact('Time-lock', '<span class="pill muted">None found</span>', 'so the LP is most likely burned');
    }
    h += '</dl>';
    return h + '</section>';
  }

  function launchList(items, now) {
    return '<ul class="launches">' + items.map((x) => {
      const cc = x.coin || {};
      const p = STATUS_PILL[x.status] || STATUS_PILL.unknown;
      return '<li><button type="button" class="launch" data-mint="' + esc(x.mint) + '"><span class="l-main"><span class="l-name">' + esc(cc.name || RC.short(x.mint)) + ' <span class="sym">' + esc(cc.symbol ? '$' + cc.symbol : '') + '</span></span>' +
        '<span class="l-meta">' + esc(x.createdAt ? 'launched ' + RC.ago(x.createdAt, now) : 'launch date unknown') + '</span></span>' +
        '<span class="l-mc">' + esc(cc.mcap !== null && cc.mcap !== undefined ? RC.usd(cc.mcap) : 'no market') + '</span>' +
        '<span class="pill ' + p[0] + '">' + p[1] + '</span></button></li>';
    }).join('') + '</ul>';
  }
  const walletLink = (addr) => '<a href="' + esc('https://solscan.io/account/' + addr) + '" target="_blank" rel="noopener noreferrer">' + esc(RC.short(addr)) + '</a>';
  const blackTag = (addr) => (settings.black[addr] ? ' <span class="pill bad">Blacklisted</span>' : '');
  const sideState = (r, k) => (r.status && r.status[k] ? r.status[k].state : null);
  const solAmt = (v) => (v >= 100 ? Math.round(v).toLocaleString() : v >= 10 ? v.toFixed(1) : v.toFixed(2));

  // Watch and blacklist, right under the coin's links.
  function actionsHTML(r, final) {
    if (!isExt && !r.creator) return '';
    let h = '<div class="actions">';
    if (isExt) {
      h += '<button type="button" class="btn sm' + (state.watching ? ' on' : '') + '" data-act="watch"' + (final ? '' : ' disabled') +
        ' title="Alerts when the dev sells, liquidity is pulled, the lock runs out or the price crashes">' + (state.watching ? 'Watching ✓' : 'Watch (alerts)') + '</button>';
    }
    if (r.creator) {
      const on = !!settings.black[r.creator];
      h += '<button type="button" class="btn sm pink' + (on ? ' on' : '') + '" data-act="black" title="Flag this dev (and the wallet that funded them) on every coin they touch">' + (on ? 'Dev blacklisted ✓' : 'Blacklist dev') + '</button>';
    }
    if (state.actNote) h += '<span class="act-note">' + esc(state.actNote) + '</span>';
    return h + '</div>';
  }

  function renderFunding(r, now) {
    let h = '<section class="block"><h2>Who funded the dev</h2>';
    const st = sideState(r, 'funding');
    const f = r.funding;
    if (!st) {
      if (r.creator && !r.wallet && !isBusy(r, 'rpc')) return h + '<p class="lede">Needs the dev wallet\'s history, which didn\'t load.</p></section>';
      if (!r.creator && !isBusy(r, 'rugcheck') && !isBusy(r, 'rpc')) return h + '<p class="lede">Needs the dev wallet, which couldn\'t be found.</p></section>';
      return h + '<div>' + sk(70) + sk(50) + '</div></section>';
    }
    if (st === 'loading') return h + '<p class="lede">Tracing where the dev\'s first SOL came from…</p><div>' + sk(70) + sk(50) + '</div></section>';
    if (!f || f.state === 'error') return h + '<p class="lede">Couldn\'t trace the funding' + (f && f.note ? ' (' + esc(f.note) + ')' : '') + '.</p></section>';
    if (f.state === 'skipped') return h + '<p class="lede">Not traced: ' + esc(f.note) + '.</p></section>';
    if (!f.funder) return h + '<p class="lede">No incoming SOL in the dev wallet\'s first transactions, so the funder is unknown.</p></section>';
    h += '<p class="lede">Serial ruggers use a fresh wallet for each coin but fund them all from the same place. This is where the dev\'s first SOL came from.</p>';
    h += '<dl class="facts">';
    const bl = settings.black[f.funder];
    h += fact('Funder', walletLink(f.funder) + ' <button type="button" class="copy" data-copy="' + esc(f.funder) + '">Copy</button>' + blackTag(f.funder), bl && bl.note ? bl.note : (f.via === 'fee payer' ? "paid the dev's first fees" : ''));
    if (f.sol) h += fact('Sent the dev', esc((f.sol < 1 ? f.sol.toFixed(3) : f.sol.toFixed(2)) + ' SOL'), f.at ? RC.ago(f.at, now) : '');
    if (f.highVolume) h += fact('Funder type', '<span class="pill muted">Exchange or service?</span>', '1,000+ transactions, so not traced further');
    else {
      if (f.funderFirstSeen) h += fact('Funder age', esc(RC.dur(now - f.funderFirstSeen)), now - f.funderFirstSeen < 3 * 24 * 3600e3 ? 'brand new' : '');
      if (f.recipients !== undefined) h += fact('Sent SOL to', '<span class="pill ' + (f.recipients >= 10 ? 'warn' : 'muted') + '">' + esc(RC.plural(f.recipients, 'wallet')) + '</span>', 'in its last ' + RC.plural(f.scanned || 0, 'transaction'));
      const fl = f.launches || [];
      const dead = fl.filter((x) => x.status === 'dead').length;
      h += fact('Coins it launched', fl.length ? '<span class="pill ' + (dead >= 2 ? 'bad' : 'warn') + '">' + fl.length + (dead ? ' · ' + dead + ' dead' : '') + '</span>' : '<span class="pill ok">None found</span>');
    }
    h += '</dl>';
    if (f.launches && f.launches.length) h += launchList(f.launches.slice(0, 20), now);
    h += '<p class="lede">' + link('https://solscan.io/account/' + f.funder, 'Funder on Solscan') + ' · ' + link('https://gmgn.ai/sol/address/' + f.funder, 'GMGN') + '</p>';
    return h + '</section>';
  }

  function renderBundle(r, now) {
    let h = '<section class="block"><h2>Launch snipers &amp; bundles</h2>';
    const st = sideState(r, 'bundle');
    const b = r.bundle;
    if (!st || st === 'loading') return h + '<p class="lede">Reading the first trades…</p><div>' + sk(70) + sk(50) + '</div></section>';
    if (!b || b.state === 'error') return h + '<p class="lede">Couldn\'t read the launch trades' + (b && b.note ? ' (' + esc(b.note) + ')' : '') + '.</p></section>';
    if (b.state === 'skipped') return h + '<p class="lede">Not checked: ' + esc(b.note) + '.</p></section>';
    const tone = b.totalPct >= 25 ? 'bad' : b.totalPct >= 10 ? 'warn' : 'ok';
    h += '<p class="lede">Wallets that bought in the first second of trading (the opening block and the two after it). A big share bought that fast is the dev bundling or bots, and they usually dump on later buyers.</p>';
    h += '<dl class="facts">';
    h += fact('Bought at launch', '<span class="pill ' + tone + '">' + (b.wallets ? esc(RC.pct(b.totalPct, 0)) : 'Nobody') + '</span>', b.wallets ? RC.plural(b.wallets, 'wallet') + ' · ' + RC.plural(b.txs, 'trade') + ' read' : 'no buyers in the first second besides the pool');
    h += fact('Still holding', '<span class="pill ' + (b.stillHeldPct >= 10 ? 'bad' : b.stillHeldPct >= 3 ? 'warn' : 'ok') + '">' + esc(RC.pct(b.stillHeldPct, 0)) + '</span>', 'of supply, among the top holders');
    if (b.devBuyPct) h += fact('Dev bought', esc(RC.pct(b.devBuyPct, 1)), 'in the same first second');
    if (b.launchAt) h += fact('Trading opened', esc(RC.ago(b.launchAt, now)));
    h += '</dl>';
    if (b.buyers && b.buyers.length) {
      h += '<ul class="wallets">' + b.buyers.map((x) => '<li><span>' + walletLink(x.owner) + blackTag(x.owner) + '</span><span>bought ' + esc(RC.pct(x.pct, 1)) + '</span><span class="w-sub">' +
        (x.holdsPct !== null ? 'still holds ' + esc(RC.pct(x.holdsPct, 1)) : 'sold, or not in the top holders') + '</span></li>').join('') + '</ul>';
    }
    return h + '</section>';
  }

  function renderHolderAges(r, now) {
    const st = sideState(r, 'holders');
    if (!st) return isBusy(r, 'rugcheck') ? '<section class="block"><h2>Top holders</h2><div>' + sk(70) + sk(50) + '</div></section>' : '';
    let h = '<section class="block"><h2>Top holders</h2>';
    const f = r.holders;
    if (st === 'loading') return h + '<p class="lede">Checking how old the top wallets are…</p><div>' + sk(70) + sk(50) + '</div></section>';
    if (!f || f.state === 'error') return h + '<p class="lede">Couldn\'t check the holders' + (f && f.note ? ' (' + esc(f.note) + ')' : '') + '.</p></section>';
    if (f.state === 'skipped') return h + '<p class="lede">Not checked: ' + esc(f.note) + '.</p></section>';
    h += '<p class="lede">Wallets first used in the last day sitting at the top of the holder list are usually the dev\'s own, faking demand.</p>';
    h += '<div class="tally"><span class="pill ' + (f.fresh >= 5 ? 'bad' : f.fresh >= 3 ? 'warn' : 'ok') + '">' + f.fresh + ' of ' + f.checked + ' fresh</span>' +
      (f.fresh ? '<span class="pill muted">' + esc(RC.pct(f.freshPct, 0)) + ' of supply</span>' : '') + '</div>';
    h += '<ul class="wallets">' + f.list.map((x) => '<li><span>' + walletLink(x.owner) + blackTag(x.owner) + '</span><span>' + esc(RC.pct(x.pct, 1)) + '</span><span class="w-sub">' +
      (x.fresh ? '<span class="pill bad">Fresh</span> ' : '') + esc(x.firstSeen ? 'first used ' + RC.ago(x.firstSeen, now) : x.txs >= 100 ? '100+ transactions' : 'age unknown') + '</span></li>').join('') + '</ul>';
    return h + '</section>';
  }

  function renderExit(a, busy) {
    let h = '<section class="block"><h2>Exit check</h2>';
    if (busy) return h + '<div>' + sk(60) + sk(40) + '</div></section>';
    const ex = a.exit;
    if (!ex) return h + '<p class="lede">No pool to sell into yet.</p></section>';
    if (ex.unsupported) return h + '<p class="lede">The main pool isn\'t paired with SOL, so the exit check is skipped.</p></section>';
    const tone = ex.sellSlipPct >= 25 ? 'bad' : ex.sellSlipPct >= 10 ? 'warn' : 'ok';
    h += '<div class="exitbar ' + tone + '"><span class="exit-n">' + (ex.approx ? '~' : '') + esc(ex.sellSlipPct.toFixed(ex.sellSlipPct < 10 ? 1 : 0)) + '%</span><span class="exit-l">lost to price impact and fees when you sell a ' + esc(solAmt(ex.sizeSol)) + ' SOL position</span></div>';
    h += '<dl class="facts">';
    h += fact('SOL in the pool', esc(solAmt(ex.poolSol) + ' SOL'));
    h += fact('Buying ' + solAmt(ex.sizeSol) + ' SOL in', esc(RC.pct(ex.buySlipPct, 1)), 'price impact + fee');
    h += fact('Biggest bag for a 5% exit', esc('~' + solAmt(Math.max(0, ex.maxSol5)) + ' SOL'));
    h += '</dl>';
    h += '<p class="hint">' + (ex.approx ? 'This pool type (bonding curve or concentrated liquidity) prices differently, so treat it as an estimate. ' : '') + 'Set your usual position size in Settings at the bottom of the page.</p>';
    return h + '</section>';
  }

  function renderCopycats(r, now) {
    const st = sideState(r, 'copycat');
    if (!st) return '';
    let h = '<section class="block"><h2>Copycats</h2>';
    const c = r.copycats;
    if (st === 'loading') return h + '<div>' + sk(60) + sk(40) + '</div></section>';
    if (!c || c.state === 'error') return h + '<p class="lede">Couldn\'t search for copies' + (c && c.note ? ' (' + esc(c.note) + ')' : '') + '.</p></section>';
    if (c.state === 'skipped') return h + '<p class="lede">Not checked: ' + esc(c.note) + '.</p></section>';
    if (!c.count) return h + '<p class="lede">No other coin uses this ticker or name.</p></section>';
    h += '<p class="lede">' + (c.original ? 'An older, bigger coin already uses this ticker. Make sure you\'re buying the one you mean.' : c.isOriginal ? 'This is the oldest coin with this ticker. The others are copies.' : 'Other coins use this ticker, but none is both older and bigger than this one.') + '</p>';
    h += '<ul class="launches">' + (c.others || []).map((o) => {
      const tag = c.original && c.original.mint === o.mint ? '<span class="pill warn">Original?</span>' : '<span class="pill muted">' + esc(o.createdAt ? RC.dur(now - o.createdAt) : '?') + '</span>';
      return '<li><button type="button" class="launch" data-mint="' + esc(o.mint) + '"><span class="l-main"><span class="l-name">' + esc(o.name || RC.short(o.mint)) + ' <span class="sym">' + esc(o.symbol ? '$' + o.symbol : '') + '</span></span>' +
        '<span class="l-meta">' + esc(o.createdAt ? 'pool opened ' + RC.ago(o.createdAt, now) : 'age unknown') + '</span></span><span class="l-mc">' + esc(o.mcap !== null && o.mcap !== undefined ? RC.usd(o.mcap) : 'no market') + '</span>' + tag + '</button></li>';
    }).join('') + '</ul>';
    return h + '</section>';
  }

  function renderX(r, now) {
    const st = (r.status && r.status.x) || null;
    const x = r.x;
    let h = '<section class="block"><h2>X account</h2>';
    if (!st || st.state === 'loading') return h + '<div>' + sk(70) + sk(55) + '</div></section>';
    if (!x) return h + '<p class="lede">Couldn\'t check the X account' + (st.note ? ' (' + esc(st.note) + ')' : '') + '.</p></section>';
    if (x.kind === 'none') return h + '<p class="lede">This coin doesn\'t link an X account, on DexScreener or in its token metadata.</p></section>';
    if (x.kind === 'invalid' || x.kind === 'other') {
      return h + '<p class="lede">The linked X address isn\'t an account or a post: <span class="mono">' + esc(x.raw || x.url) + '</span></p></section>';
    }
    const xlink = (handle) => '<a href="' + esc('https://x.com/' + handle) + '" target="_blank" rel="noopener noreferrer">@' + esc(handle) + '</a>';
    if (x.kind === 'community') {
      return h + '<p class="lede">Links to an X Community rather than an account. ' + link(x.url, 'Open community') + '</p></section>';
    }
    if (x.state === 'error') {
      return h + '<dl class="facts">' + fact('Linked', x.handle ? xlink(x.handle) : esc(x.url)) + fact('Lookup', '<span class="pill muted">Unavailable</span>', x.error) + '</dl></section>';
    }
    h += '<dl class="facts">';
    if (x.kind === 'tweet') {
      h += fact('Linked to', '<span class="pill warn">A single post</span>');
      if (x.state === 'notfound') h += fact('Post', '<span class="pill bad">Deleted</span>');
      else if (x.state === 'private') h += fact('Post', '<span class="pill muted">Private</span>');
      if (x.tweet) {
        if (x.tweet.author) h += fact('Posted by', xlink(x.tweet.author));
        if (x.tweet.createdAt) h += fact('Posted', esc(RC.ago(x.tweet.createdAt, now)));
      }
    } else {
      h += fact('Account', xlink(x.handle), x.source === 'token metadata' ? 'from the token metadata' : 'from DexScreener');
      if (x.state === 'suspended') h += fact('Status', '<span class="pill bad">Suspended</span>');
      else if (x.state === 'notfound') h += fact('Status', '<span class="pill bad">Doesn\'t exist</span>');
      else if (x.state === 'private') h += fact('Status', '<span class="pill muted">Protected</span>');
    }
    const u = x.user;
    if (u) {
      if (u.joined) {
        const launchTimes = [r.coin && r.coin.createdAt, r.rug && RC.toMs(r.rug.detectedAt)].filter(Boolean);
        const launchAt = launchTimes.length ? Math.min.apply(null, launchTimes) : null;
        let note = '';
        if (x.kind === 'profile' && launchAt) note = u.joined <= launchAt ? RC.dur(launchAt - u.joined) + ' before launch' : RC.dur(u.joined - launchAt) + ' after launch';
        h += fact('Created', esc(new Date(u.joined).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' })), note);
      }
      h += fact('Followers', esc(RC.count(u.followers)) + (u.following !== null ? ' <span class="note">following ' + esc(RC.count(u.following)) + '</span>' : ''));
      if (u.posts !== null) h += fact('Posts', esc(RC.count(u.posts)));
      if (u.renames !== null) {
        const tone = u.renames === 0 ? 'ok' : (u.renames >= 3 || (u.lastRename && now - u.lastRename < 30 * 24 * 3600e3)) ? 'bad' : 'warn';
        h += fact('@ changes', '<span class="pill ' + tone + '">' + (u.renames === 0 ? 'Never' : esc(RC.plural(u.renames, 'time'))) + '</span>', u.lastRename ? 'last ' + RC.ago(u.lastRename, now) : '');
      }
      if (u.basedIn) h += fact('Based in', esc(u.basedIn), 'according to X');
      if (u.verified) h += fact('Check mark', '<span class="pill ' + (u.verifiedType === 'organization' ? 'ok' : 'muted') + '">' + (u.verifiedType === 'organization' ? 'Gold (organization)' : 'Blue (paid)') + '</span>');
      if (x.kind === 'profile') {
        const cas = u.description.match(/[1-9A-HJ-NP-Za-km-z]{32,44}/g) || [];
        const ca = cas.indexOf(r.mint) >= 0 ? '<span class="pill ok">This coin</span>' : cas.length ? '<span class="pill warn">Different address</span>' : '<span class="pill muted">None</span>';
        h += fact('Contract in bio', ca);
      }
    }
    h += '</dl>';
    if (x.kind === 'tweet' && x.tweet && x.tweet.text) h += '<blockquote class="quote">' + esc(x.tweet.text) + '</blockquote>';
    else if (u && u.description) h += '<blockquote class="quote">' + esc(u.description) + '</blockquote>';
    h += '<p class="lede">' + link(x.url, 'Open on X') + '</p>';
    return h + '</section>';
  }

  async function scanOlder() {
    const r = state.current;
    if (!r || !r.launches || state.scanning) return;
    const my = state.token;
    state.scanning = true;
    try {
      await client.scanMore(r, 100, (rep) => { if (my === state.token) renderReport(rep, true); });
    } finally {
      state.scanning = false;
      if (my === state.token && state.current) {
        const a = renderReport(state.current, true);
        remember(state.current, a);
      }
    }
  }

  async function copyText(text, btn) {
    const done = () => { const o = btn.textContent; btn.textContent = 'Copied'; setTimeout(() => { btn.textContent = o; }, 1200); };
    try { await navigator.clipboard.writeText(text); done(); }
    catch (e) {
      const ta = document.createElement('textarea');
      ta.value = text; ta.setAttribute('readonly', ''); ta.style.position = 'fixed'; ta.style.opacity = '0';
      document.body.appendChild(ta); ta.select();
      try { document.execCommand('copy'); done(); } catch (e2) { /* the address is still visible to copy by hand */ }
      ta.remove();
    }
  }

  // ---------- watch and blacklist ----------
  function actionNote(t) {
    state.actNote = t;
    rerender();
    // Clear it in place: rebuilding the report here could swallow a click that's in progress.
    setTimeout(() => {
      if (state.actNote !== t) return;
      state.actNote = '';
      const n = el.report.querySelector('.act-note');
      if (n) n.remove();
    }, 6000);
  }
  // Only what the watcher needs, not the whole report.
  const watchSeed = (r) => ({
    mint: r.mint, creator: r.creator,
    coin: { symbol: r.coin && r.coin.symbol, name: r.coin && r.coin.name, liquidity: r.coin && r.coin.liquidity },
    rug: r.rug ? { markets: r.rug.markets, lockers: r.rug.lockers, token: r.rug.token ? { supply: r.rug.token.supply } : null } : null,
    mintInfo: r.mintInfo ? { supply: r.mintInfo.supply } : null,
    wallet: r.wallet ? { sigs: r.wallet.sigs.slice(0, 1) } : null
  });
  async function toggleWatch() {
    const r = state.current;
    if (!r || !isExt) return;
    const on = !state.watching;
    const res = await sendBg({ type: 'rugchecker:watch', addr: r.mint, on, report: watchSeed(r) });
    if (!res || res.error) { actionNote((res && res.error) || "Couldn't reach the extension. Reload this page."); return; }
    state.watching = !!res.watching;
    renderWatchList(res.list);
    actionNote(on ? 'Watching. Alerts if the dev sells, liquidity is pulled, the lock runs out or it crashes.' : 'Stopped watching.');
  }
  async function unwatch(mint) {
    const res = await sendBg({ type: 'rugchecker:watch', addr: mint, on: false });
    if (res && res.list) renderWatchList(res.list);
    if (state.current && state.current.mint === mint) { state.watching = false; rerender(); }
  }

  async function saveBlacklist(list) {
    await prefs.set('blacklist', list);
    settings.black = list;
    renderBlackList();
    if (state.current) {
      try { await client.refreshBlacklist(state.current); } catch (e) { /* shows on the next check */ }
      rerender();
    }
    if (state.feed === 'filtered') renderFiltered();
  }
  async function toggleBlack() {
    const r = state.current;
    if (!r || !r.creator) return;
    const label = coinLabel(r.coin);
    const funder = r.funding && r.funding.funder && !r.funding.highVolume ? r.funding.funder : null;
    const list = Object.assign({}, await prefs.get('blacklist', {}));
    const on = !list[r.creator];
    if (on) {
      list[r.creator] = { note: 'dev of ' + label, at: Date.now() };
      if (funder && !list[funder]) list[funder] = { note: 'funded the dev of ' + label, at: Date.now() };
    } else {
      delete list[r.creator];
      if (funder && list[funder] && /^funded the dev of /.test(list[funder].note || '')) delete list[funder];
    }
    await saveBlacklist(list);
    actionNote(on ? 'Blacklisted the dev' + (funder ? ' and their funder' : '') + '. Any coin they touch now gets flagged.' : 'Removed from your blacklist.');
  }
  async function removeBlack(addr) {
    const list = Object.assign({}, await prefs.get('blacklist', {}));
    delete list[addr];
    await saveBlacklist(list);
  }
  async function addBlackManual() {
    const v = el.blackAddr.value.trim();
    if (!RC.isAddress(v)) { el.blackMsg.textContent = "That isn't a Solana address."; return; }
    const list = Object.assign({}, await prefs.get('blacklist', {}));
    list[v] = { note: 'added by hand', at: Date.now() };
    await saveBlacklist(list);
    el.blackAddr.value = '';
    el.blackMsg.textContent = 'Added.';
  }
  async function exportBlack(btn) {
    await copyText(JSON.stringify(settings.black, null, 1), btn);
    el.blackMsg.textContent = 'Copied ' + RC.plural(Object.keys(settings.black).length, 'wallet') + '. Paste it into Import on another device.';
  }
  async function importBlack() {
    if (el.blackImport.hidden) { el.blackImport.hidden = false; el.blackImport.focus(); el.blackMsg.textContent = 'Paste the JSON, then press Import JSON again.'; return; }
    let incoming;
    try { incoming = JSON.parse(el.blackImport.value); } catch (e) { el.blackMsg.textContent = "That isn't valid JSON."; return; }
    const list = Object.assign({}, await prefs.get('blacklist', {}));
    let added = 0;
    const take = (addr, v) => { if (RC.isAddress(addr) && !list[addr]) { list[addr] = { note: String((v && v.note) || 'imported').slice(0, 140), at: (v && v.at) || Date.now() }; added++; } };
    if (Array.isArray(incoming)) incoming.forEach((a) => take(typeof a === 'string' ? a : a && a.addr, a));
    else if (incoming && typeof incoming === 'object') Object.keys(incoming).forEach((k) => take(k, incoming[k]));
    await saveBlacklist(list);
    el.blackImport.value = '';
    el.blackImport.hidden = true;
    el.blackMsg.textContent = 'Imported ' + RC.plural(added, 'new wallet') + '.';
  }

  function renderBlackList() {
    const keys = Object.keys(settings.black).sort((a, b) => (settings.black[b].at || 0) - (settings.black[a].at || 0));
    el.blackList.innerHTML = keys.length ? keys.map((k) => {
      const e = settings.black[k] || {};
      return '<li><span>' + walletLink(k) + '<span class="m-sub">' + esc((e.note || '') + (e.at ? ' · ' + RC.ago(e.at) : '')) + '</span></span><button type="button" class="copy" data-act="black-del" data-addr="' + esc(k) + '">Remove</button></li>';
    }).join('') : '<li><span class="empty">Empty. Press "Blacklist dev" on a report to add one.</span></li>';
  }
  function renderWatchList(list) {
    if (!isExt) return;
    const keys = Object.keys(list || {});
    el.watchList.innerHTML = keys.length ? keys.map((m) => {
      const e = list[m] || {};
      const last = e.alerts && e.alerts[0];
      return '<li><span><button type="button" class="link" data-mint="' + esc(m) + '">' + esc(e.symbol ? '$' + e.symbol : RC.short(m)) + '</button>' +
        '<span class="m-sub' + (last ? ' alert-line' : '') + '">' + esc(last ? RC.ago(last.at) + ': ' + last.text : 'since ' + RC.ago(e.addedAt) + ', no alerts yet') + '</span></span>' +
        '<button type="button" class="copy" data-act="unwatch" data-addr="' + esc(m) + '">Stop</button></li>';
    }).join('') : '<li><span class="empty">Nothing yet. Press "Watch" on a coin you hold.</span></li>';
  }

  async function loadSettings() {
    const size = Number(await prefs.get('exitSize', 1));
    settings.exitSize = size > 0 ? size : 1;
    settings.black = (await prefs.get('blacklist', {})) || {};
    el.exitSize.value = settings.exitSize;
    client = makeClient();
    renderBlackList();
    if (isExt) {
      el.badgeSet.hidden = false;
      el.watchSet.hidden = false;
      el.badgesOn.checked = (await prefs.get('badges', true)) !== false;
      const res = await sendBg({ type: 'rugchecker:watchList' });
      renderWatchList((res && res.list) || {});
      sendBg({ type: 'rugchecker:seenAlerts' });
      // Changes made in another tab or by the background (alerts, blacklist edits from the on-page panel)
      chrome.storage.onChanged.addListener((c, area) => {
        if (area !== 'local') return;
        if (c.watch) renderWatchList(c.watch.newValue || {});
        if (c.blacklist) {
          settings.black = c.blacklist.newValue || {};
          renderBlackList();
          if (state.current) client.refreshBlacklist(state.current).then(rerender, () => {});
          if (state.feed === 'filtered') renderFiltered();
        }
      });
    }
  }
  el.exitSize.addEventListener('change', async () => {
    const v = Number(el.exitSize.value);
    if (!(v > 0)) { el.exitSize.value = settings.exitSize; return; }
    if (v === settings.exitSize) return;
    settings.exitSize = v;
    await prefs.set('exitSize', v);
    client = makeClient();
    // This fires when the box loses focus, often because you clicked something else:
    // let that click finish before the report is rebuilt under it.
    if (state.current) { state.current.exitSize = v; setTimeout(rerender, 250); }
  });
  el.badgesOn.addEventListener('change', () => { prefs.set('badges', el.badgesOn.checked); });

  // ---------- filtered launch feed ----------
  const RULES_KEY = 'rc.rules';
  const DEEP_MAX = 8;
  const getRules = () => Object.assign({}, RC.DEFAULT_RULES, store.get(RULES_KEY, {}));
  function fillRules() {
    const r = getRules();
    Array.from(el.rules.elements).forEach((f) => {
      if (!f.name) return;
      if (f.type === 'checkbox') f.checked = !!r[f.name];
      else f.value = r[f.name] === null || r[f.name] === undefined ? '' : r[f.name];
    });
    el.rules.querySelector('[data-deep]').hidden = !r.deep;
  }
  function readRules() {
    const out = {};
    Array.from(el.rules.elements).forEach((f) => {
      if (!f.name) return;
      if (f.type === 'checkbox') out[f.name] = f.checked;
      else if (f.type === 'number') out[f.name] = f.value === '' ? null : Number(f.value);
      else out[f.name] = f.value;
    });
    return out;
  }
  el.rules.addEventListener('submit', (e) => e.preventDefault());
  el.rules.addEventListener('change', () => {
    const r = readRules();
    store.set(RULES_KEY, r);
    el.rules.querySelector('[data-deep]').hidden = !r.deep;
    renderFiltered();
    const F = state.filter;
    // Coins that now pass the quick rules still need their dev checked
    if (r.deep && !F.running && F.items.length) {
      F.running = 'deep';
      deepPass(F.runId).then(() => { F.running = false; F.at = Date.now(); renderFiltered(); });
    }
  });
  el.list.addEventListener('toggle', (e) => {
    if (e.target && e.target.classList && e.target.classList.contains('outs')) state.filter.showOuts = e.target.open;
  }, true);

  async function eachLimit(items, n, fn) {
    const q = items.slice();
    const worker = async () => { while (q.length) await fn(q.shift()); };
    await Promise.all(Array.from({ length: Math.min(n, q.length) }, worker));
  }

  async function runFilter() {
    const F = state.filter;
    const my = ++F.runId;
    F.running = true;
    F.error = null;
    F.items = [];
    F.res = new Map();
    F.done = 0; F.total = 0; F.deepDone = 0; F.deepTotal = 0;
    renderFiltered();
    let coins;
    try { coins = await client.candidates(45); } catch (e) {
      if (my !== F.runId) return;
      F.running = false;
      F.error = RC.describeError(e);
      renderFiltered();
      return;
    }
    if (my !== F.runId) return;
    F.items = coins;
    F.total = coins.length;
    coins.forEach((c) => F.res.set(c.mint, { coin: c, stage: 'queued' }));
    renderFiltered();
    // Quick check on every candidate, two at a time
    await eachLimit(coins, 2, async (c) => {
      if (my !== F.runId) return;
      const e = F.res.get(c.mint);
      try {
        e.r = await client.lite(c.mint);
        if (e.r.coin && (e.r.coin.name || e.r.coin.symbol)) e.coin = Object.assign({}, c, e.r.coin, { icon: e.r.coin.icon || c.icon });
        e.stage = 'quick';
      } catch (err) { e.stage = 'error'; e.error = RC.describeError(err); }
      F.done++;
      if (my === F.runId) renderFilteredSoon();
    });
    if (my !== F.runId) return;
    F.running = 'deep';
    await deepPass(my);
    if (my !== F.runId) return;
    F.running = false;
    F.at = Date.now();
    renderFiltered();
  }
  // Full check (dev, funder, snipers, holders) on the coins that pass the quick rules, one at a time.
  async function deepPass(my) {
    const F = state.filter;
    if (!getRules().deep) return;
    const todo = F.items.map((c) => F.res.get(c.mint))
      .filter((e) => e && e.r && e.r.lite && e.stage !== 'deep' && RC.filterCheck(e.r, getRules()).pass)
      .slice(0, DEEP_MAX);
    F.deepTotal = todo.length;
    F.deepDone = 0;
    renderFilteredSoon();
    for (const e of todo) {
      if (my !== F.runId || !getRules().deep) return;
      if (!RC.filterCheck(e.r, getRules()).pass) { F.deepDone++; continue; } // rules changed meanwhile
      e.stage = 'deep';
      renderFilteredSoon();
      try { e.r = await client.inspect(e.r.mint); } catch (err) { e.deepError = RC.describeError(err); }
      e.stage = 'done';
      F.deepDone++;
      if (my === F.runId) renderFilteredSoon();
    }
  }

  let filterFrame = null;
  function renderFilteredSoon() {
    if (filterFrame) return;
    filterFrame = setTimeout(() => { filterFrame = null; renderFiltered(); }, 120);
  }
  function filteredRow(e, chk, fails) {
    const c = e.coin || {};
    const meta = [c.createdAt ? RC.ago(c.createdAt) : 'no pool yet'];
    if (c.liquidity !== null && c.liquidity !== undefined) meta.push('liq ' + RC.usd(c.liquidity));
    let why;
    if (fails) why = fails.join(' · ');
    else if (e.stage === 'deep') why = 'passed quick rules · checking the dev…';
    else if (chk.deep) why = 'passed · dev checked';
    else why = getRules().deep ? 'passed quick rules · dev check queued' : 'passed';
    const tone = chk ? chk.tone : 'muted';
    return '<li><button type="button" class="coin" data-mint="' + esc(c.mint || (e.r && e.r.mint)) + '">' + icon(c) +
      '<span class="coin-main"><span class="coin-name">' + esc(c.name || 'Unnamed coin') + ' <span class="sym">' + esc(coinLabel(c)) + '</span></span>' +
      '<span class="coin-meta">' + esc(meta.join(' · ')) + '</span><span class="why' + (fails ? '' : ' pass') + '">' + esc(why) + '</span></span>' +
      '<span class="coin-num"><span class="score-pill ' + esc(tone) + '" title="risk score">' + esc(chk ? chk.score : '?') + '</span><span>' + esc(c.mcap !== null && c.mcap !== undefined ? RC.usd(c.mcap) : '–') + '</span></span></button></li>';
  }
  function renderFiltered() {
    if (state.feed !== 'filtered' || el.home.hidden) return;
    const F = state.filter;
    const rules = getRules();
    if (F.error && !F.items.length) { el.filterStatus.textContent = ''; listMessage("Couldn't load new coins (" + F.error + '). Tap Refresh to try again.'); return; }
    if (!F.items.length) { el.filterStatus.textContent = F.running ? 'Finding new coins…' : ''; if (F.running) skeletonList(); else listMessage('Tap Refresh to scan the newest coins.'); return; }
    const pass = [];
    const out = [];
    F.items.forEach((c) => {
      const e = F.res.get(c.mint);
      if (!e) return;
      if (e.stage === 'error') { out.push({ e, fails: ["couldn't check: " + e.error] }); return; }
      if (!e.r) return; // not checked yet
      const chk = RC.filterCheck(e.r, rules);
      if (chk.pass) pass.push({ e, chk });
      else out.push({ e, chk, fails: chk.fails });
    });
    pass.sort((x, y) => (y.chk.deep - x.chk.deep) || (x.chk.score - y.chk.score));
    if (F.running === true) el.filterStatus.textContent = 'Quick check ' + F.done + ' of ' + F.total + ' · ' + pass.length + ' passing';
    else if (F.running === 'deep') el.filterStatus.textContent = 'Checking devs ' + Math.min(F.deepDone + 1, F.deepTotal) + ' of ' + F.deepTotal + '…';
    else el.filterStatus.textContent = pass.length + ' of ' + F.items.length + ' pass · scanned ' + (!F.at || Date.now() - F.at < 60e3 ? 'just now' : RC.ago(F.at));
    let h = pass.map((x) => filteredRow(x.e, x.chk, null)).join('');
    if (out.length) {
      h += '<li><details class="outs"' + (F.showOuts ? ' open' : '') + '><summary>' + out.length + ' filtered out (see why)</summary><ul class="coins">' +
        out.map((x) => filteredRow(x.e, x.chk, x.fails)).join('') + '</ul></details></li>';
    }
    el.listMsg.hidden = true;
    if (!pass.length && !F.running) {
      el.listMsg.textContent = 'None of the ' + F.items.length + ' newest coins pass your rules right now. Loosen a rule or tap Refresh in a minute.';
      el.listMsg.hidden = false;
    }
    el.list.innerHTML = h;
  }

  // ---------- events ----------
  document.addEventListener('click', (e) => {
    const t = e.target.closest('button, a');
    if (!t) return;
    if (t.dataset.copy) { e.preventDefault(); copyText(t.dataset.copy, t); return; }
    if (t.dataset.act === 'home') { showHome(); loadFeed(state.feed); return; }
    if (t.dataset.act === 'scan') { scanOlder(); return; }
    if (t.dataset.act === 'watch') { toggleWatch(); return; }
    if (t.dataset.act === 'black') { toggleBlack(); return; }
    if (t.dataset.act === 'unwatch') { unwatch(t.dataset.addr); return; }
    if (t.dataset.act === 'black-del') { removeBlack(t.dataset.addr); return; }
    if (t.dataset.act === 'black-add') { addBlackManual(); return; }
    if (t.dataset.act === 'black-export') { exportBlack(t); return; }
    if (t.dataset.act === 'black-import') { importBlack(); return; }
    if (t.dataset.act === 'rules-reset') { store.set(RULES_KEY, {}); fillRules(); renderFiltered(); return; }
    if (t.dataset.mint && t.tagName === 'BUTTON') { openCoin(t.dataset.mint); return; }
    if (t.dataset.feed) { loadFeed(t.dataset.feed); return; }
  });
  el.homeLink.addEventListener('click', (e) => { e.preventDefault(); showHome(); loadFeed(state.feed); });
  el.refresh.addEventListener('click', () => {
    if (state.feed === 'search') return runSearch(state.lastSearch);
    if (state.feed === 'filtered') return runFilter();
    loadFeed(state.feed, true);
  });

  async function runSearch(q) {
    q = String(q || '').trim();
    if (!q) return;
    if (RC.isAddress(q)) { openCoin(q); return; }
    state.lastSearch = q;
    state.feed = 'search';
    el.tabSearch.hidden = false;
    el.tabSearch.textContent = '“' + (q.length > 14 ? q.slice(0, 14) + '…' : q) + '”';
    setTabs();
    showHome();
    skeletonList();
    try {
      const items = await client.search(q);
      state.lists.search = items;
      if (state.feed === 'search') renderList(items, 'No Solana coins match “' + q + '”.');
    } catch (e) {
      if (state.feed === 'search') listMessage('Search failed (' + RC.describeError(e) + ').');
    }
  }
  el.form.addEventListener('submit', (e) => { e.preventDefault(); runSearch(el.q.value); });

  // Paste a full link (DexScreener, pump.fun, GMGN…) and we pull the address out of it.
  el.q.addEventListener('paste', () => {
    setTimeout(() => {
      const v = el.q.value.trim();
      if (RC.isAddress(v)) return;
      const m = v.match(/[1-9A-HJ-NP-Za-km-z]{32,44}/);
      if (/^https?:\/\//i.test(v) && m) el.q.value = m[0];
    }, 0);
  });

  // Settings: custom RPC
  el.rpcInput.value = store.get('rc.rpc', '');
  el.rpcForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const v = el.rpcInput.value.trim();
    if (v && !/^https:\/\//i.test(v)) { el.rpcMsg.textContent = 'Use an https:// address.'; return; }
    if (v && isExt && chrome.permissions) {
      let ok = false;
      try { ok = await chrome.permissions.request({ origins: [new URL(v).origin + '/*'] }); } catch (err) { ok = false; }
      if (!ok) { el.rpcMsg.textContent = 'Chrome needs permission to reach that address. Saved nothing.'; return; }
    }
    store.set('rc.rpc', v);
    if (isExt && chrome.storage) { try { chrome.storage.local.set({ rpcUrl: v }); } catch (err) { /* the on-page button keeps the public RPCs */ } }
    client = makeClient();
    el.rpcMsg.textContent = v ? 'Saved. New checks use your RPC first.' : 'Cleared. Using the free public RPCs.';
  });

  window.addEventListener('hashchange', () => {
    const h = decodeURIComponent(location.hash.slice(1));
    if (RC.isAddress(h) && (!state.current || state.current.mint !== h)) openCoin(h);
  });

  // ---------- start ----------
  renderRecent();
  fillRules();
  (async () => {
    await loadSettings();
    const start = decodeURIComponent(location.hash.slice(1));
    if (RC.isAddress(start)) openCoin(start);
    loadFeed('new');
  })();
})();
